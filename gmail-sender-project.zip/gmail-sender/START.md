# ⚡ Quick Start (5 menit)

## 1. Install semua dependencies

```bash
# Backend
cd backend && npm install && cd ..

# Frontend
cd frontend && npm install && cd ..
```

## 2. Setup .env Backend

```bash
cd backend
cp .env.example .env
```

Buka `backend/.env` dan isi:
```
GOOGLE_CLIENT_ID=      ← dari Google Cloud Console
GOOGLE_CLIENT_SECRET=  ← dari Google Cloud Console
SESSION_SECRET=        ← string random (min 32 karakter)
```

> 📖 Panduan lengkap setup Google Cloud ada di README.md

## 3. Jalankan Backend

```bash
cd backend
npm run dev
# → Server berjalan di http://localhost:3001
```

## 4. Jalankan Frontend (terminal baru)

```bash
cd frontend
npm start
# → App terbuka di http://localhost:3000
```

## 5. Mulai Pakai!

1. 🔐 Login dengan Google
2. 👤 Isi Profil & upload CV
3. 🏢 Tambah email perusahaan
4. 🚀 Kirim email lamaran!

---

## Troubleshooting Cepat

| Masalah | Solusi |
|---------|--------|
| `redirect_uri_mismatch` | Tambahkan `http://localhost:3001/auth/callback` di Google Console |
| CORS error | Pastikan `FRONTEND_URL=http://localhost:3000` di backend `.env` |
| Session hilang | Pastikan `SESSION_SECRET` sudah diset |
