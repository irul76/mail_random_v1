import React, { useEffect, useState, useCallback } from 'react';
import { profileAPI } from '../utils/api';
import toast from 'react-hot-toast';
import { Save, Upload, Download, FileText, Plus, Trash2, RefreshCw } from 'lucide-react';

// Build preview text from form fields
function buildPreview(form) {
  const experiences = (form.work_experiences || [])
    .filter(e => e.trim())
    .map((e, i) => `${i + 1}.${e}`)
    .join('\n');
  const skillsList = (form.skills || [])
    .filter(s => s.trim())
    .map(s => `- ${s}`)
    .join('\n');

  return `Kepada Yth
Bapak/Ibu HRD [Nama Perusahaan]

Dengan hormat,

Sehubungan dengan adanya informasi lowongan pekerjaan di perusahaan yang bapak atau ibu pimpin, maka dengan ini saya berniat melamar pekerjaan untuk posisi [POSISI]. Data diri saya sebagai berikut :

Nama : ${form.full_name || '...'}
Tempat, tanggal lahir : ${form.birth_place || '...'}, ${form.birth_date || '...'}
Agama : ${form.religion || '...'}
Usia : ${form.age || '...'} Tahun
Jenis Kelamin : ${form.gender || '...'}
Alamat : ${form.address || '...'}
Tinggi Badan : ${form.height || '...'} Cm
Berat Badan : ${form.weight || '...'} Kg
Pendidikan Terakhir : ${form.education || '...'}
Lulusan Tahun : ${form.graduation_year || '...'}
Vaksin : ${form.vaccine || '...'}
Pengalaman Kerja :
${experiences || '...'}
No HP/WA : ${form.phone || '...'}
Email : ${form.email_contact || '...'}
Keahlian :
${skillsList || '...'}

Atas perhatian bapak atau ibu saya ucapkan terimakasih.

Hormat saya
( ${form.full_name || '...'} )`;
}

const EMPTY_FORM = {
  full_name: '', birth_place: '', birth_date: '', religion: '', age: '',
  gender: 'Laki - Laki', address: '', height: '', weight: '',
  education: '', graduation_year: '', vaccine: '',
  phone: '', email_contact: '',
  work_experiences: [''],
  skills: [''],
};

export default function ProfilePage() {
  const [form, setForm] = useState(EMPTY_FORM);
  const [emailBody, setEmailBody] = useState(buildPreview(EMPTY_FORM));
  const [emailBodyEdited, setEmailBodyEdited] = useState(false);
  const [cvFile, setCvFile] = useState(null);
  const [existingCV, setExistingCV] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Auto-sync preview when form changes (only if not manually edited)
  useEffect(() => {
    if (!emailBodyEdited) {
      setEmailBody(buildPreview(form));
    }
  }, [form, emailBodyEdited]);

  useEffect(() => {
    profileAPI.get().then(({ data }) => {
      if (data.profile) {
        const p = data.profile;
        const loadedForm = {
          full_name: p.full_name || '',
          birth_place: p.birth_place || '',
          birth_date: p.birth_date || '',
          religion: p.religion || '',
          age: p.age || '',
          gender: p.gender || 'Laki - Laki',
          address: p.address || '',
          height: p.height || '',
          weight: p.weight || '',
          education: p.education || '',
          graduation_year: p.graduation_year || '',
          vaccine: p.vaccine || '',
          phone: p.phone || '',
          email_contact: p.email_contact || '',
          work_experiences: p.work_experiences?.length ? p.work_experiences : [''],
          skills: p.skills?.length ? p.skills : [''],
        };
        setForm(loadedForm);

        // If custom email_template saved, load it as edited
        if (p.email_template && p.email_template !== buildPreview(loadedForm)) {
          setEmailBody(p.email_template);
          setEmailBodyEdited(true);
        } else {
          setEmailBody(buildPreview(loadedForm));
          setEmailBodyEdited(false);
        }

        setExistingCV(p.cv_original_name || null);
      }
    }).catch(() => toast.error('Gagal memuat profil')).finally(() => setLoading(false));
  }, []);

  const set = (field, val) => setForm(p => ({ ...p, [field]: val }));

  const addExp = () => setForm(p => ({ ...p, work_experiences: [...p.work_experiences, ''] }));
  const removeExp = (i) => setForm(p => ({ ...p, work_experiences: p.work_experiences.filter((_, idx) => idx !== i) }));
  const setExp = (i, val) => setForm(p => { const arr = [...p.work_experiences]; arr[i] = val; return { ...p, work_experiences: arr }; });

  const addSkill = () => setForm(p => ({ ...p, skills: [...p.skills, ''] }));
  const removeSkill = (i) => setForm(p => ({ ...p, skills: p.skills.filter((_, idx) => idx !== i) }));
  const setSkill = (i, val) => setForm(p => { const arr = [...p.skills]; arr[i] = val; return { ...p, skills: arr }; });

  const resetEmailBody = () => {
    setEmailBody(buildPreview(form));
    setEmailBodyEdited(false);
    toast.success('Email direset ke format otomatis');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const formData = new FormData();
      Object.entries(form).forEach(([k, v]) => {
        if (Array.isArray(v)) formData.append(k, JSON.stringify(v.filter(x => x.trim())));
        else formData.append(k, v);
      });
      // Save the email body (whether auto or manually edited)
      formData.append('email_template', emailBody);
      if (cvFile) formData.append('cv', cvFile);
      const { data } = await profileAPI.update(formData);
      setExistingCV(data.profile.cv_original_name);
      setCvFile(null);
      toast.success('Profil berhasil disimpan!');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Gagal menyimpan');
    } finally {
      setSaving(false);
    }
  };

  const fieldStyle = { marginBottom: 12 };
  const rowStyle = { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 };

  if (loading) return (
    <div className="page-body" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <span className="spinner" /> Memuat...
    </div>
  );

  return (
    <div>
      <div className="page-header">
        <h1>Profil Pelamar</h1>
        <p>Data ini digunakan otomatis saat mengirim email lamaran</p>
      </div>

      <div className="page-body">
        <form onSubmit={handleSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>

            {/* ─── LEFT COLUMN ─── */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

              {/* Data Diri */}
              <div className="card">
                <div style={{ fontWeight: 700, marginBottom: 14, fontSize: 14 }}>📋 Data Diri</div>

                <div style={fieldStyle}>
                  <label className="label">Nama Lengkap</label>
                  <input className="input" value={form.full_name} onChange={e => set('full_name', e.target.value)} placeholder="AHMAD KHOLILUR ROHMAN" />
                </div>

                <div style={rowStyle}>
                  <div>
                    <label className="label">Tempat Lahir</label>
                    <input className="input" value={form.birth_place} onChange={e => set('birth_place', e.target.value)} placeholder="REMBANG" />
                  </div>
                  <div>
                    <label className="label">Tanggal Lahir</label>
                    <input className="input" value={form.birth_date} onChange={e => set('birth_date', e.target.value)} placeholder="8 MEI 2002" />
                  </div>
                </div>

                <div style={rowStyle}>
                  <div>
                    <label className="label">Agama</label>
                    <input className="input" value={form.religion} onChange={e => set('religion', e.target.value)} placeholder="ISLAM" />
                  </div>
                  <div>
                    <label className="label">Usia</label>
                    <input className="input" value={form.age} onChange={e => set('age', e.target.value)} placeholder="23" />
                  </div>
                </div>

                <div style={fieldStyle}>
                  <label className="label">Jenis Kelamin</label>
                  <select className="input" value={form.gender} onChange={e => set('gender', e.target.value)}
                    style={{ appearance: 'none', cursor: 'pointer' }}>
                    <option>Laki - Laki</option>
                    <option>Perempuan</option>
                  </select>
                </div>

                <div style={fieldStyle}>
                  <label className="label">Alamat</label>
                  <input className="input" value={form.address} onChange={e => set('address', e.target.value)} placeholder="Desa CIANTRA KECAMATAN CIKARANG SELATAN" />
                </div>

                <div style={rowStyle}>
                  <div>
                    <label className="label">Tinggi Badan (cm)</label>
                    <input className="input" value={form.height} onChange={e => set('height', e.target.value)} placeholder="165" />
                  </div>
                  <div>
                    <label className="label">Berat Badan (kg)</label>
                    <input className="input" value={form.weight} onChange={e => set('weight', e.target.value)} placeholder="60" />
                  </div>
                </div>

                <div style={rowStyle}>
                  <div>
                    <label className="label">Pendidikan Terakhir</label>
                    <input className="input" value={form.education} onChange={e => set('education', e.target.value)} placeholder="SMK" />
                  </div>
                  <div>
                    <label className="label">Lulusan Tahun</label>
                    <input className="input" value={form.graduation_year} onChange={e => set('graduation_year', e.target.value)} placeholder="2020" />
                  </div>
                </div>

                <div style={fieldStyle}>
                  <label className="label">Vaksin</label>
                  <input className="input" value={form.vaccine} onChange={e => set('vaccine', e.target.value)} placeholder="ke 3 / Booster" />
                </div>

                <div style={rowStyle}>
                  <div>
                    <label className="label">No HP/WA</label>
                    <input className="input" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="089603538618" />
                  </div>
                  <div>
                    <label className="label">Email Kontak</label>
                    <input className="input" value={form.email_contact} onChange={e => set('email_contact', e.target.value)} placeholder="kamu@gmail.com" />
                  </div>
                </div>
              </div>

              {/* Pengalaman Kerja */}
              <div className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>💼 Pengalaman Kerja</div>
                  <button type="button" onClick={addExp} className="btn btn-secondary btn-sm">
                    <Plus size={13} /> Tambah
                  </button>
                </div>
                {form.work_experiences.map((exp, i) => (
                  <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                    <input
                      className="input"
                      value={exp}
                      onChange={e => setExp(i, e.target.value)}
                      placeholder="Contoh: PT AISIN INDONESIA - PPIC Delivery - 2 Tahun"
                    />
                    {form.work_experiences.length > 1 && (
                      <button type="button" onClick={() => removeExp(i)}
                        className="btn btn-ghost btn-sm btn-icon"
                        style={{ color: 'var(--danger)', flexShrink: 0 }}>
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                ))}
              </div>

              {/* Keahlian */}
              <div className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>⚡ Keahlian</div>
                  <button type="button" onClick={addSkill} className="btn btn-secondary btn-sm">
                    <Plus size={13} /> Tambah
                  </button>
                </div>
                {form.skills.map((skill, i) => (
                  <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                    <input
                      className="input"
                      value={skill}
                      onChange={e => setSkill(i, e.target.value)}
                      placeholder="Contoh: WELDING SPOT"
                    />
                    {form.skills.length > 1 && (
                      <button type="button" onClick={() => removeSkill(i)}
                        className="btn btn-ghost btn-sm btn-icon"
                        style={{ color: 'var(--danger)', flexShrink: 0 }}>
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                ))}
              </div>

              {/* CV Upload */}
              <div className="card">
                <div style={{ fontWeight: 700, marginBottom: 12, fontSize: 14 }}>
                  <FileText size={14} style={{ marginRight: 6, verticalAlign: 'middle' }} />
                  File CV
                </div>
                {existingCV && !cvFile && (
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 12px', background: 'var(--success-subtle)', border: '1.5px solid var(--success)', borderRadius: 'var(--radius-sm)', marginBottom: 10 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
                      <FileText size={14} color="var(--success)" />
                      <span>{existingCV}</span>
                    </div>
                    <a href={profileAPI.downloadCV()} target="_blank" rel="noreferrer" className="btn btn-ghost btn-sm" style={{ color: 'var(--success)' }}>
                      <Download size={13} /> Unduh
                    </a>
                  </div>
                )}
                {cvFile && (
                  <div style={{ padding: '10px 12px', background: 'var(--info-subtle)', border: '1.5px solid var(--info)', borderRadius: 'var(--radius-sm)', fontSize: 13, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 8 }}>
                    <FileText size={14} color="var(--info)" />
                    {cvFile.name} ({(cvFile.size / 1024).toFixed(0)} KB)
                  </div>
                )}
                <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 12, border: '2px dashed var(--border-strong)', borderRadius: 'var(--radius-sm)', cursor: 'pointer', fontSize: 13, color: 'var(--text-secondary)', transition: 'border-color 0.15s' }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent)'}
                  onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border-strong)'}>
                  <Upload size={15} /> {existingCV ? 'Ganti CV' : 'Upload CV'} (PDF/DOC, maks 10MB)
                  <input type="file" accept=".pdf,.doc,.docx" onChange={e => setCvFile(e.target.files[0])} style={{ display: 'none' }} />
                </label>
              </div>
            </div>

            {/* ─── RIGHT COLUMN — Editable Email Body ─── */}
            <div className="card" style={{ display: 'flex', flexDirection: 'column' }}>
              {/* Header */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <div style={{ fontWeight: 700, fontSize: 14 }}>✏️ Isi Email</div>
                <button
                  type="button"
                  onClick={resetEmailBody}
                  className="btn btn-secondary btn-sm"
                  title="Reset ke format otomatis dari data form kiri"
                >
                  <RefreshCw size={12} /> Reset Otomatis
                </button>
              </div>

              {/* Status bar */}
              <div style={{
                fontSize: 11, marginBottom: 10, padding: '6px 10px',
                borderRadius: 'var(--radius-sm)',
                background: emailBodyEdited ? 'var(--warning-subtle)' : 'var(--success-subtle)',
                color: emailBodyEdited ? 'var(--warning)' : 'var(--success)',
                border: `1.5px solid ${emailBodyEdited ? 'var(--warning)' : 'var(--success)'}`,
              }}>
                {emailBodyEdited
                  ? '⚠️ Mode edit manual — perubahan form kiri tidak otomatis tersync. Klik "Reset Otomatis" untuk sinkron ulang.'
                  : '✅ Otomatis — isi email sinkron dengan form kiri secara realtime.'}
              </div>

              {/* Editable textarea */}
              <textarea
                value={emailBody}
                onChange={e => {
                  setEmailBody(e.target.value);
                  setEmailBodyEdited(true);
                }}
                style={{
                  flex: 1,
                  minHeight: 560,
                  background: 'var(--bg-subtle)',
                  border: emailBodyEdited
                    ? '2px solid var(--warning)'
                    : '1.5px solid var(--border)',
                  borderRadius: 'var(--radius-sm)',
                  padding: '14px 16px',
                  fontSize: 13,
                  lineHeight: 1.85,
                  color: 'var(--text-primary)',
                  fontFamily: 'var(--font)',
                  resize: 'vertical',
                  outline: 'none',
                  transition: 'border-color 0.15s',
                }}
                onFocus={e => {
                  if (!emailBodyEdited) e.target.style.borderColor = 'var(--accent)';
                }}
                onBlur={e => {
                  if (!emailBodyEdited) e.target.style.borderColor = 'var(--border)';
                }}
                placeholder="Isi email akan muncul otomatis setelah mengisi data di form kiri..."
              />

              <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 8 }}>
                💡 <strong>[Nama Perusahaan]</strong> dan <strong>[POSISI]</strong> akan diisi otomatis saat pengiriman.
              </p>
            </div>
          </div>

          {/* Save button */}
          <div style={{ marginTop: 20, display: 'flex', justifyContent: 'flex-end' }}>
            <button type="submit" className="btn btn-primary btn-lg" disabled={saving}>
              {saving
                ? <><span className="spinner" style={{ width: 16, height: 16 }} /> Menyimpan...</>
                : <><Save size={16} /> Simpan Profil</>}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
