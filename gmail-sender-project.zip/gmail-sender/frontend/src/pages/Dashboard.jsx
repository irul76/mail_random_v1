import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { sendingAPI } from '../utils/api';
import toast from 'react-hot-toast';
import { Building2, Send, XCircle, Activity, ChevronRight, Clock, Ban, AlertTriangle } from 'lucide-react';

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetch = () => sendingAPI.getStats().then(({ data }) => setStats(data)).catch(() => toast.error('Gagal memuat statistik')).finally(() => setLoading(false));
    fetch();
    const interval = setInterval(fetch, 5000);
    return () => clearInterval(interval);
  }, []);

  const statCards = stats ? [
    { label: 'Total Perusahaan', value: stats.totalCompanies, color: 'var(--info)', bg: 'var(--info-subtle)', icon: Building2, action: () => navigate('/emails') },
    { label: 'Email Terkirim', value: stats.totalSent, color: 'var(--success)', bg: 'var(--success-subtle)', icon: Send },
    { label: 'Email Gagal', value: stats.totalFailed, color: 'var(--danger)', bg: 'var(--danger-subtle)', icon: XCircle },
    { label: 'Diblokir', value: stats.totalBlocked || 0, color: 'var(--danger)', bg: 'var(--danger-subtle)', icon: Ban },
    { label: 'Masuk Spam', value: stats.totalSpam || 0, color: 'var(--warning)', bg: 'var(--warning-subtle)', icon: AlertTriangle },
    { label: 'Status', value: stats.isActive ? 'AKTIF' : (stats.lastSession?.status?.toUpperCase() || 'IDLE'), color: stats.isActive ? 'var(--success)' : 'var(--text-muted)', bg: stats.isActive ? 'var(--success-subtle)' : 'var(--bg-subtle)', icon: Activity, isText: true },
  ] : [];

  const session = stats?.lastSession;
  const progress = session?.total_emails > 0 ? Math.round(((session.sent_count + session.failed_count) / session.total_emails) * 100) : 0;

  const quickActions = [
    { label: 'Tambah Email Perusahaan', to: '/emails', icon: Building2 },
    { label: 'Edit Profil Pelamar', to: '/profile', icon: Activity },
    { label: 'Mulai Kirim Email', to: '/send', icon: Send },
    { label: 'Lihat Log Pengiriman', to: '/logs', icon: Clock },
  ];

  return (
    <div>
      <div className="page-header">
        <h1>Dashboard</h1>
        <p>Pantau status pengiriman email lamaran Anda</p>
      </div>
      <div className="page-body">
        {loading ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, color: 'var(--text-muted)' }}><span className="spinner" /> Memuat...</div>
        ) : (
          <div className="fade-in">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12, marginBottom: 24 }}>
              {statCards.map(({ label, value, color, bg, icon: Icon, isText, action }, i) => (
                <div key={i} className="card" onClick={action} style={{ cursor: action ? 'pointer' : 'default', transition: 'transform 0.1s' }}
                  onMouseEnter={e => action && (e.currentTarget.style.transform = 'translateY(-2px)')}
                  onMouseLeave={e => action && (e.currentTarget.style.transform = 'none')}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                    <div style={{ width: 32, height: 32, background: bg, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Icon size={15} color={color} />
                    </div>
                    <span style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</span>
                  </div>
                  <div style={{ fontSize: isText ? 16 : 30, fontWeight: 800, fontFamily: 'var(--font-mono)', letterSpacing: '-0.04em', color: isText ? color : 'var(--text-primary)' }}>
                    {value}
                  </div>
                </div>
              ))}
            </div>

            {session && (
              <div className="card" style={{ marginBottom: 24 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
                  <div>
                    <div style={{ fontWeight: 700, marginBottom: 2 }}>Sesi Terkini</div>
                    <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Posisi: <strong>{session.subject}</strong></div>
                  </div>
                  <span className={`badge ${stats?.isActive ? 'badge-success' : session.status === 'completed' ? 'badge-info' : 'badge-neutral'}`}>
                    {stats?.isActive && <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'currentColor', display: 'inline-block', marginRight: 4, animation: 'pulse 1s infinite' }} />}
                    {session.status}
                  </span>
                </div>
                <div className="progress-bar" style={{ marginBottom: 8 }}>
                  <div className="progress-fill" style={{ width: `${progress}%` }} />
                </div>
                <div style={{ display: 'flex', gap: 20, fontSize: 12, color: 'var(--text-secondary)', flexWrap: 'wrap' }}>
                  <span>✅ Terkirim: <strong style={{ color: 'var(--success)' }}>{session.sent_count}</strong></span>
                  <span>❌ Gagal: <strong style={{ color: 'var(--danger)' }}>{session.failed_count}</strong></span>
                  <span>🚫 Diblokir: <strong>{session.blocked_count || 0}</strong></span>
                  <span>⚠️ Spam: <strong>{session.spam_count || 0}</strong></span>
                  <span>📊 Total: <strong>{session.total_emails}</strong></span>
                  <span>📈 {progress}%</span>
                </div>
                <button onClick={() => navigate('/send')} className="btn btn-secondary btn-sm" style={{ marginTop: 12 }}>
                  <Clock size={13} /> Kelola Pengiriman
                </button>
              </div>
            )}

            <div className="card">
              <div style={{ fontWeight: 700, marginBottom: 12, fontSize: 14 }}>Aksi Cepat</div>
              {quickActions.map(({ label, to, icon: Icon }) => (
                <button key={to} onClick={() => navigate(to)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', padding: '10px 12px', background: 'var(--bg-subtle)', border: '1.5px solid var(--border)', borderRadius: 'var(--radius-sm)', cursor: 'pointer', fontFamily: 'var(--font)', fontSize: 13, color: 'var(--text-primary)', marginBottom: 6, transition: 'background 0.1s' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-hover)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'var(--bg-subtle)'}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                    <Icon size={15} color="var(--accent)" />{label}
                  </div>
                  <ChevronRight size={14} color="var(--text-muted)" />
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
