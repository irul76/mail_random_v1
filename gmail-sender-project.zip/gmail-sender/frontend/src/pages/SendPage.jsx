import React, { useEffect, useState, useRef, useCallback } from 'react';
import { sendingAPI, emailsAPI } from '../utils/api';
import toast from 'react-hot-toast';
import {
  Play, Pause, RotateCcw, Square, Clock, CheckCircle,
  XCircle, AlertTriangle, Zap, Mail, Target, Hash,
  SortAsc, Layers, Ban, Filter
} from 'lucide-react';

const ALPHABET = 'abcdefghijklmnopqrstuvwxyz'.split('');

function formatTime(seconds) {
  if (seconds < 60) return `${seconds} detik`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return s > 0 ? `${m} mnt ${s} dtk` : `${m} menit`;
}

function formatElapsed(seconds) {
  if (seconds < 60) return `${seconds} dtk`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export default function SendPage() {
  const [subject, setSubject] = useState('');

  // Delay
  const [delaySeconds, setDelaySeconds] = useState(60);
  const [delayUnit, setDelayUnit] = useState('seconds'); // 'seconds' | 'minutes'

  // Send mode
  const [sendMode, setSendMode] = useState('all'); // 'all' | 'group' | 'select' | 'manual'

  // Group filter state
  const [groupType, setGroupType] = useState('abjad'); // 'abjad' | 'range' | 'count' | 'domain'
  const [groupLetters, setGroupLetters] = useState([]);
  const [groupFrom, setGroupFrom] = useState(0);
  const [groupTo, setGroupTo] = useState(499);
  const [groupCount, setGroupCount] = useState(100);
  const [groupOffset, setGroupOffset] = useState(0);
  const [groupDomains, setGroupDomains] = useState('');
  const [groupPreview, setGroupPreview] = useState(null);
  const [previewLoading, setPreviewLoading] = useState(false);

  // Manual/select
  const [manualEmails, setManualEmails] = useState('');
  const [allEmails, setAllEmails] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]);

  // Session state
  const [session, setSession] = useState(null);
  const [isActive, setIsActive] = useState(false);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);
  const [countdown, setCountdown] = useState(null);
  const [lastEmail, setLastEmail] = useState(null);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const sseRef = useRef(null);

  const connectSSE = useCallback(() => {
    if (sseRef.current) sseRef.current.close();
    const es = new EventSource(sendingAPI.getProgressURL(), { withCredentials: true });
    sseRef.current = es;
    es.onmessage = (e) => {
      const data = JSON.parse(e.data);
      if (data.type === 'session') setSession(data.session);
      if (data.type === 'progress') {
        setCountdown(null);
        setLastEmail({ email: data.lastEmail, status: data.lastStatus });
        setElapsedSeconds(data.elapsedSeconds || 0);
        setSession(prev => prev ? { ...prev, sent_count: data.sent, failed_count: data.failed, status: 'running' } : prev);
      }
      if (data.type === 'countdown') {
        setCountdown(data.nextIn);
        setSession(prev => prev ? { ...prev, sent_count: data.sent, failed_count: data.failed } : prev);
      }
      if (data.type === 'paused') { setIsActive(false); setCountdown(null); setSession(p => p ? { ...p, status: 'paused' } : p); }
      if (data.type === 'resumed') { setIsActive(true); setSession(p => p ? { ...p, status: 'running' } : p); }
      if (data.type === 'stopped') { setIsActive(false); setCountdown(null); setSession(p => p ? { ...p, status: 'stopped' } : p); }
      if (data.type === 'completed') {
        setIsActive(false); setCountdown(null);
        setSession(p => p ? { ...p, status: 'completed', sent_count: data.sent, failed_count: data.failed } : p);
        toast.success(`🎉 Selesai! ${data.sent} terkirim, ${data.failed} gagal.`);
      }
    };
    es.onerror = () => setTimeout(connectSSE, 3000);
  }, []);

  useEffect(() => {
    sendingAPI.getStatus().then(({ data }) => { setSession(data.session); setIsActive(data.isActive); }).finally(() => setLoading(false));
    emailsAPI.getAll().then(({ data }) => setAllEmails(data.emails.filter(e => e.is_valid)));
    connectSSE();
    return () => sseRef.current?.close();
  }, [connectSSE]);

  // Build group_filter object
  const buildGroupFilter = () => {
    if (sendMode !== 'group') return null;
    switch (groupType) {
      case 'abjad': return { type: 'abjad', letters: groupLetters };
      case 'range': return { type: 'range', from: groupFrom, to: groupTo };
      case 'count': return { type: 'count', limit: groupCount, offset: groupOffset };
      case 'domain': return { type: 'domain', domains: groupDomains.split(/[\n,]+/).map(d => d.trim()).filter(Boolean) };
      default: return null;
    }
  };

  const handlePreviewGroup = async () => {
    const gf = buildGroupFilter();
    if (!gf) return;
    setPreviewLoading(true);
    try {
      const { data } = await sendingAPI.previewGroup(gf);
      setGroupPreview(data);
    } catch { toast.error('Gagal preview grup'); }
    finally { setPreviewLoading(false); }
  };

  // Actual delay in seconds
  const actualDelaySeconds = delayUnit === 'minutes' ? delaySeconds * 60 : delaySeconds;

  const handleStart = async () => {
    if (!subject.trim()) { toast.error('Masukkan posisi yang dilamar'); return; }

    let target_emails = null;
    const group_filter = buildGroupFilter();

    if (sendMode === 'select') {
      target_emails = allEmails.filter(e => selectedIds.includes(e.id)).map(e => e.email);
      if (target_emails.length === 0) { toast.error('Pilih minimal 1 email'); return; }
    } else if (sendMode === 'manual') {
      target_emails = manualEmails.split(/[\n,;]+/).map(e => e.trim()).filter(Boolean);
      if (target_emails.length === 0) { toast.error('Masukkan minimal 1 email'); return; }
    }

    setActionLoading('start');
    try {
      const { data } = await sendingAPI.start(subject, target_emails, actualDelaySeconds, group_filter);
      setIsActive(true); setLastEmail(null); setCountdown(null); setElapsedSeconds(0);
      toast.success(`Pengiriman dimulai! ${data.totalEmails} email dengan jeda ${formatTime(actualDelaySeconds)}`);
      sendingAPI.getStatus().then(({ data: s }) => setSession(s.session));
    } catch (err) { toast.error(err.response?.data?.error || 'Gagal memulai'); }
    finally { setActionLoading(null); }
  };

  const handlePause = async () => { setActionLoading('pause'); try { await sendingAPI.pause(); } catch (err) { toast.error(err.response?.data?.error); } finally { setActionLoading(null); } };
  const handleResume = async () => { setActionLoading('resume'); try { await sendingAPI.resume(); } catch (err) { toast.error(err.response?.data?.error); } finally { setActionLoading(null); } };
  const handleStop = async () => {
    if (!window.confirm('Yakin ingin menghentikan pengiriman?')) return;
    setActionLoading('stop');
    try { await sendingAPI.stop(); } catch (err) { toast.error(err.response?.data?.error); } finally { setActionLoading(null); }
  };

  const toggleLetter = (l) => setGroupLetters(prev => prev.includes(l) ? prev.filter(x => x !== l) : [...prev, l]);
  const toggleSelect = (id) => setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  const canStart = !isActive && (!session || ['completed', 'stopped', 'failed'].includes(session?.status));
  const isPaused = session?.status === 'paused';
  const isRunning = session?.status === 'running' && isActive;
  const isCompleted = session?.status === 'completed';
  const progress = session?.total_emails > 0
    ? Math.round(((session.sent_count + session.failed_count) / session.total_emails) * 100) : 0;
  const remaining = session ? Math.max(0, session.total_emails - session.sent_count - session.failed_count) : 0;
  const estimatedRemaining = remaining * actualDelaySeconds;

  if (loading) return <div className="page-body" style={{ display: 'flex', alignItems: 'center', gap: 10 }}><span className="spinner" /> Memuat...</div>;

  return (
    <div>
      <div className="page-header">
        <h1>Kirim Email</h1>
        <p>Kirim email lamaran otomatis dengan pengaturan delay dan pengelompokan</p>
      </div>

      <div className="page-body">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>

          {/* ─── LEFT: Setup ─── */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

            {canStart && (
              <div className="card fade-in">
                <div style={{ fontWeight: 700, marginBottom: 14, fontSize: 14 }}>
                  <Zap size={14} style={{ marginRight: 6, verticalAlign: 'middle', color: 'var(--accent)' }} />
                  Pengaturan Pengiriman
                </div>

                {/* Posisi */}
                <div style={{ marginBottom: 14 }}>
                  <label className="label">Posisi yang Dilamar</label>
                  <input className="input" value={subject} onChange={e => setSubject(e.target.value)}
                    placeholder="Operator Produksi, Staff Gudang, Welder..." />
                </div>

                {/* Delay */}
                <div style={{ marginBottom: 14 }}>
                  <label className="label">Jeda Antar Email</label>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <input
                      className="input"
                      type="number"
                      min={1}
                      value={delaySeconds}
                      onChange={e => setDelaySeconds(Math.max(1, parseInt(e.target.value) || 1))}
                      style={{ flex: 1 }}
                    />
                    <div style={{ display: 'flex', background: 'var(--bg-subtle)', border: '1.5px solid var(--border)', borderRadius: 'var(--radius-sm)', overflow: 'hidden', flexShrink: 0 }}>
                      {[['seconds', 'Detik'], ['minutes', 'Menit']].map(([val, label]) => (
                        <button key={val} type="button" onClick={() => setDelayUnit(val)}
                          style={{
                            padding: '8px 14px', border: 'none', cursor: 'pointer',
                            fontFamily: 'var(--font)', fontSize: 12, fontWeight: 600,
                            background: delayUnit === val ? 'var(--accent)' : 'transparent',
                            color: delayUnit === val ? '#fff' : 'var(--text-secondary)',
                            transition: 'all 0.15s',
                          }}>
                          {label}
                        </button>
                      ))}
                    </div>
                  </div>
                  <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 5 }}>
                    Total jeda: <strong>{formatTime(actualDelaySeconds)}</strong> per email
                    {allEmails.length > 0 && <span> · estimasi total {formatTime(allEmails.length * actualDelaySeconds)}</span>}
                  </p>
                </div>

                {/* Mode Kirim */}
                <div style={{ marginBottom: 14 }}>
                  <label className="label">Mode Pengiriman</label>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                    {[
                      { key: 'all', icon: Mail, label: 'Semua Email', desc: `${allEmails.length} email` },
                      { key: 'group', icon: Layers, label: 'Pengelompokan', desc: 'Filter grup' },
                      { key: 'select', icon: Target, label: 'Pilih Manual', desc: 'Centang satu-satu' },
                      { key: 'manual', icon: Hash, label: 'Ketik Email', desc: 'Input langsung' },
                    ].map(({ key, icon: Icon, label, desc }) => (
                      <button key={key} type="button" onClick={() => setSendMode(key)}
                        style={{
                          display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                          padding: '10px 12px', border: `2px solid ${sendMode === key ? 'var(--accent)' : 'var(--border)'}`,
                          borderRadius: 'var(--radius-sm)', cursor: 'pointer', textAlign: 'left',
                          background: sendMode === key ? 'var(--accent-subtle)' : 'var(--bg-subtle)',
                          transition: 'all 0.15s', fontFamily: 'var(--font)',
                        }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
                          <Icon size={13} color={sendMode === key ? 'var(--accent)' : 'var(--text-muted)'} />
                          <span style={{ fontSize: 12, fontWeight: 600, color: sendMode === key ? 'var(--accent)' : 'var(--text-primary)' }}>{label}</span>
                        </div>
                        <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>{desc}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* ── GROUP FILTER ── */}
                {sendMode === 'group' && (
                  <div style={{ marginBottom: 14, padding: 14, background: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--border)' }}>
                    <div style={{ fontWeight: 600, fontSize: 12, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
                      <Filter size={12} /> Jenis Pengelompokan
                    </div>

                    {/* Group type tabs */}
                    <div style={{ display: 'flex', gap: 4, marginBottom: 12, flexWrap: 'wrap' }}>
                      {[
                        { key: 'abjad', icon: SortAsc, label: 'Abjad' },
                        { key: 'range', icon: Hash, label: 'Urutan' },
                        { key: 'count', icon: Layers, label: 'Jumlah' },
                        { key: 'domain', icon: Mail, label: 'Domain' },
                      ].map(({ key, icon: Icon, label }) => (
                        <button key={key} type="button" onClick={() => { setGroupType(key); setGroupPreview(null); }}
                          className={`btn btn-sm ${groupType === key ? 'btn-primary' : 'btn-secondary'}`}>
                          <Icon size={11} /> {label}
                        </button>
                      ))}
                    </div>

                    {/* Abjad */}
                    {groupType === 'abjad' && (
                      <div>
                        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 8 }}>
                          Pilih huruf awal email yang akan dikirim:
                        </p>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 8 }}>
                          {ALPHABET.map(l => (
                            <button key={l} type="button" onClick={() => { toggleLetter(l); setGroupPreview(null); }}
                              style={{
                                width: 30, height: 30, border: `1.5px solid ${groupLetters.includes(l) ? 'var(--accent)' : 'var(--border)'}`,
                                borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: 700,
                                background: groupLetters.includes(l) ? 'var(--accent)' : 'var(--bg-card)',
                                color: groupLetters.includes(l) ? '#fff' : 'var(--text-secondary)',
                                fontFamily: 'var(--font-mono)', transition: 'all 0.1s',
                              }}>
                              {l.toUpperCase()}
                            </button>
                          ))}
                        </div>
                        <div style={{ display: 'flex', gap: 6 }}>
                          <button type="button" onClick={() => { setGroupLetters([...ALPHABET]); setGroupPreview(null); }} className="btn btn-ghost btn-sm" style={{ fontSize: 10 }}>Pilih Semua</button>
                          <button type="button" onClick={() => { setGroupLetters([]); setGroupPreview(null); }} className="btn btn-ghost btn-sm" style={{ fontSize: 10 }}>Kosongkan</button>
                        </div>
                        {groupLetters.length > 0 && (
                          <p style={{ fontSize: 11, color: 'var(--accent)', marginTop: 6 }}>
                            Huruf terpilih: {groupLetters.map(l => l.toUpperCase()).join(', ')}
                          </p>
                        )}
                      </div>
                    )}

                    {/* Range (urutan/index) */}
                    {groupType === 'range' && (
                      <div>
                        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 8 }}>
                          Email diurutkan A-Z, pilih dari urutan ke berapa sampai ke berapa:
                        </p>
                        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
                          <div style={{ flex: 1 }}>
                            <label className="label" style={{ fontSize: 10 }}>Dari urutan ke-</label>
                            <input className="input" type="number" min={1} value={groupFrom + 1}
                              onChange={e => { setGroupFrom(Math.max(0, parseInt(e.target.value) - 1 || 0)); setGroupPreview(null); }} />
                          </div>
                          <div style={{ color: 'var(--text-muted)', paddingTop: 16 }}>—</div>
                          <div style={{ flex: 1 }}>
                            <label className="label" style={{ fontSize: 10 }}>Sampai urutan ke-</label>
                            <input className="input" type="number" min={1} value={groupTo + 1}
                              onChange={e => { setGroupTo(Math.max(groupFrom, parseInt(e.target.value) - 1 || 0)); setGroupPreview(null); }} />
                          </div>
                        </div>
                        <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                          Contoh: urutan 1 sampai 500 = 500 email pertama (A-Z)
                        </p>
                      </div>
                    )}

                    {/* Count (jumlah + offset) */}
                    {groupType === 'count' && (
                      <div>
                        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 8 }}>
                          Kirim sejumlah email tertentu, mulai dari posisi tertentu:
                        </p>
                        <div style={{ display: 'flex', gap: 8, marginBottom: 6 }}>
                          <div style={{ flex: 1 }}>
                            <label className="label" style={{ fontSize: 10 }}>Mulai dari posisi ke-</label>
                            <input className="input" type="number" min={1} value={groupOffset + 1}
                              onChange={e => { setGroupOffset(Math.max(0, parseInt(e.target.value) - 1 || 0)); setGroupPreview(null); }} />
                          </div>
                          <div style={{ flex: 1 }}>
                            <label className="label" style={{ fontSize: 10 }}>Kirim sebanyak</label>
                            <input className="input" type="number" min={1} value={groupCount}
                              onChange={e => { setGroupCount(Math.max(1, parseInt(e.target.value) || 1)); setGroupPreview(null); }} />
                          </div>
                        </div>
                        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                          {[50, 100, 200, 500].map(n => (
                            <button key={n} type="button" onClick={() => { setGroupCount(n); setGroupPreview(null); }}
                              className={`btn btn-sm ${groupCount === n ? 'btn-primary' : 'btn-secondary'}`}>
                              {n} email
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Domain */}
                    {groupType === 'domain' && (
                      <div>
                        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 8 }}>
                          Kirim hanya ke domain tertentu (pisah dengan enter/koma):
                        </p>
                        <textarea className="textarea" rows={3} value={groupDomains}
                          onChange={e => { setGroupDomains(e.target.value); setGroupPreview(null); }}
                          placeholder="gmail.com&#10;yahoo.com&#10;perusahaan.co.id"
                          style={{ fontFamily: 'var(--font-mono)', fontSize: 12 }} />
                      </div>
                    )}

                    {/* Preview button */}
                    <button type="button" onClick={handlePreviewGroup} disabled={previewLoading}
                      className="btn btn-secondary btn-sm" style={{ marginTop: 10 }}>
                      {previewLoading ? <span className="spinner" style={{ width: 12, height: 12 }} /> : <Filter size={12} />}
                      Preview Hasil Filter
                    </button>

                    {/* Preview result */}
                    {groupPreview && (
                      <div style={{ marginTop: 10, padding: '10px 12px', background: 'var(--info-subtle)', border: '1.5px solid var(--info)', borderRadius: 'var(--radius-sm)' }}>
                        <div style={{ fontWeight: 600, fontSize: 12, color: 'var(--info)', marginBottom: 6 }}>
                          📊 {groupPreview.total} email akan dikirim (dari {groupPreview.totalAll} total)
                        </div>
                        {groupPreview.preview.length > 0 && (
                          <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>
                            Contoh pertama: {groupPreview.preview.slice(0, 5).join(', ')}
                            {groupPreview.preview.length > 5 && ` ...dan ${groupPreview.total - 5} lainnya`}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Manual input */}
                {sendMode === 'manual' && (
                  <div style={{ marginBottom: 14 }}>
                    <label className="label">Email Tujuan</label>
                    <textarea className="textarea" rows={4} value={manualEmails}
                      onChange={e => setManualEmails(e.target.value)}
                      placeholder="hr@perusahaan1.com&#10;rekrutmen@perusahaan2.com&#10;Pisahkan dengan enter, koma, atau titik koma"
                      style={{ fontFamily: 'var(--font-mono)', fontSize: 12 }} />
                  </div>
                )}

                {/* Select from list */}
                {sendMode === 'select' && (
                  <div style={{ marginBottom: 14 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                      <label className="label" style={{ margin: 0 }}>
                        Pilih Email <span style={{ color: 'var(--accent)' }}>({selectedIds.length} dipilih)</span>
                      </label>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button type="button" onClick={() => setSelectedIds(allEmails.map(e => e.id))} className="btn btn-ghost btn-sm" style={{ fontSize: 11 }}>Semua</button>
                        <button type="button" onClick={() => setSelectedIds([])} className="btn btn-ghost btn-sm" style={{ fontSize: 11 }}>Reset</button>
                      </div>
                    </div>
                    <div style={{ maxHeight: 220, overflowY: 'auto', border: '1.5px solid var(--border)', borderRadius: 'var(--radius-sm)' }}>
                      {allEmails.length === 0
                        ? <div style={{ padding: 16, textAlign: 'center', color: 'var(--text-muted)', fontSize: 12 }}>Belum ada email di daftar</div>
                        : allEmails.map(email => (
                          <label key={email.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', cursor: 'pointer', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
                            <input type="checkbox" checked={selectedIds.includes(email.id)} onChange={() => toggleSelect(email.id)} />
                            <span style={{ flex: 1, fontFamily: 'var(--font-mono)', fontSize: 12 }}>{email.email}</span>
                            {email.company_name && <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{email.company_name}</span>}
                          </label>
                        ))
                      }
                    </div>
                  </div>
                )}

                {/* Start button */}
                <button onClick={handleStart} disabled={!!actionLoading || !subject.trim()} className="btn btn-primary btn-lg" style={{ width: '100%', justifyContent: 'center' }}>
                  {actionLoading === 'start'
                    ? <><span className="spinner" style={{ width: 16, height: 16 }} /> Memulai...</>
                    : <><Play size={16} /> Mulai Kirim</>}
                </button>
              </div>
            )}

            {/* Active session controls */}
            {session && !canStart && (
              <div className="card fade-in">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
                  <div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Posisi dilamar</div>
                    <div style={{ fontWeight: 700, fontSize: 16 }}>{session.subject}</div>
                    {session.delay_seconds && (
                      <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>
                        Jeda: {formatTime(session.delay_seconds)} per email
                      </div>
                    )}
                  </div>
                  <span style={{
                    padding: '5px 12px', borderRadius: 20, fontSize: 12, fontWeight: 700,
                    background: isRunning ? 'var(--success-subtle)' : isPaused ? 'var(--warning-subtle)' : isCompleted ? 'var(--info-subtle)' : 'var(--bg-subtle)',
                    color: isRunning ? 'var(--success)' : isPaused ? 'var(--warning)' : isCompleted ? 'var(--info)' : 'var(--text-muted)',
                    whiteSpace: 'nowrap',
                  }}>
                    {isRunning ? '🟢 Berjalan' : isPaused ? '⏸ Dijeda' : isCompleted ? '✅ Selesai' : '⏹ Dihentikan'}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="progress-bar" style={{ marginBottom: 6, height: 12 }}>
                  <div className="progress-fill" style={{ width: `${progress}%` }} />
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14, fontSize: 12, color: 'var(--text-muted)' }}>
                  <span>{progress}% selesai</span>
                  <span>{session.sent_count + session.failed_count} / {session.total_emails}</span>
                </div>

                {/* Countdown */}
                {countdown !== null && isRunning && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px', background: 'var(--info-subtle)', border: '1.5px solid var(--info)', borderRadius: 'var(--radius-sm)', marginBottom: 10, fontSize: 13, color: 'var(--info)' }}>
                    <Clock size={14} />
                    Email berikutnya dalam <strong style={{ fontFamily: 'var(--font-mono)', fontSize: 16 }}>{countdown}s</strong>
                    <div style={{ flex: 1, height: 4, background: 'var(--border)', borderRadius: 2, overflow: 'hidden', marginLeft: 8 }}>
                      <div style={{
                        height: '100%', background: 'var(--info)', borderRadius: 2,
                        width: `${100 - (countdown / (session.delay_seconds || 60)) * 100}%`,
                        transition: 'width 0.5s linear',
                      }} />
                    </div>
                  </div>
                )}

                {/* Last email result */}
                {lastEmail && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: lastEmail.status === 'sent' ? 'var(--success-subtle)' : 'var(--danger-subtle)', borderRadius: 'var(--radius-sm)', marginBottom: 10, fontSize: 12, color: lastEmail.status === 'sent' ? 'var(--success)' : 'var(--danger)' }}>
                    {lastEmail.status === 'sent' ? <CheckCircle size={13} /> : <XCircle size={13} />}
                    {lastEmail.status === 'sent' ? 'Terkirim' : lastEmail.status === 'blocked' ? 'Diblokir' : 'Gagal'}: <strong>{lastEmail.email}</strong>
                  </div>
                )}

                {/* Action buttons */}
                {!isCompleted && (
                  <div style={{ display: 'flex', gap: 8, marginBottom: 0 }}>
                    {isRunning && <button onClick={handlePause} disabled={!!actionLoading} className="btn btn-secondary"><Pause size={14} /> Jeda</button>}
                    {isPaused && <button onClick={handleResume} disabled={!!actionLoading} className="btn btn-success"><RotateCcw size={14} /> Lanjutkan</button>}
                    <button onClick={handleStop} disabled={!!actionLoading} className="btn btn-danger"><Square size={14} /> Hentikan</button>
                  </div>
                )}
                {isCompleted && (
                  <div style={{ padding: 14, background: 'var(--success-subtle)', border: '1.5px solid var(--success)', borderRadius: 'var(--radius-sm)', color: 'var(--success)', fontWeight: 600, textAlign: 'center' }}>
                    🎉 Pengiriman selesai!
                  </div>
                )}
              </div>
            )}

            {/* Anti-spam warning */}
            <div style={{ display: 'flex', gap: 10, padding: '12px 14px', background: 'var(--warning-subtle)', border: '1.5px solid var(--warning)', borderRadius: 'var(--radius-sm)', fontSize: 12, color: 'var(--text-secondary)' }}>
              <AlertTriangle size={14} color="var(--warning)" style={{ flexShrink: 0, marginTop: 1 }} />
              <div><strong style={{ color: 'var(--warning)' }}>Tips Anti-Spam:</strong> Gunakan jeda minimal 30 detik. Makin kecil jeda, makin besar risiko email masuk spam atau akun diblokir Google.</div>
            </div>
          </div>

          {/* ─── RIGHT: Stats ─── */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {session && (
              <div className="card">
                <div style={{ fontWeight: 700, marginBottom: 14, fontSize: 14 }}>📊 Statistik Sesi</div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 14 }}>
                  {[
                    { label: 'Terkirim', value: session.sent_count, color: 'var(--success)', bg: 'var(--success-subtle)', icon: '✅' },
                    { label: 'Gagal', value: session.failed_count, color: 'var(--danger)', bg: 'var(--danger-subtle)', icon: '❌' },
                    { label: 'Sisa', value: remaining, color: 'var(--info)', bg: 'var(--info-subtle)', icon: '📋' },
                    { label: 'Diblokir', value: session.blocked_count || 0, color: 'var(--danger)', bg: 'var(--danger-subtle)', icon: '🚫' },
                    { label: 'Spam', value: session.spam_count || 0, color: 'var(--warning)', bg: 'var(--warning-subtle)', icon: '⚠️' },
                    { label: 'Total', value: session.total_emails, color: 'var(--text-primary)', bg: 'var(--bg-subtle)', icon: '📊' },
                  ].map(({ label, value, color, bg, icon }) => (
                    <div key={label} style={{ textAlign: 'center', padding: '12px 6px', background: bg, borderRadius: 8 }}>
                      <div style={{ fontSize: 14, marginBottom: 4 }}>{icon}</div>
                      <div style={{ fontSize: 24, fontWeight: 800, fontFamily: 'var(--font-mono)', color, letterSpacing: '-0.04em' }}>{value}</div>
                      <div style={{ fontSize: 10, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase' }}>{label}</div>
                    </div>
                  ))}
                </div>

                {/* Time info */}
                <div style={{ padding: '10px 14px', background: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)', fontSize: 12, color: 'var(--text-secondary)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span>⏱ Berjalan</span>
                    <strong style={{ fontFamily: 'var(--font-mono)' }}>{formatElapsed(elapsedSeconds)}</strong>
                  </div>
                  {isRunning && remaining > 0 && (
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span>⏳ Estimasi selesai</span>
                      <strong>~{formatTime(estimatedRemaining)}</strong>
                    </div>
                  )}
                  {session.delay_seconds && (
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
                      <span>🕐 Jeda per email</span>
                      <strong>{formatTime(session.delay_seconds)}</strong>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Info box */}
            <div className="card" style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.8 }}>
              <div style={{ fontWeight: 700, marginBottom: 8, color: 'var(--text-primary)', fontSize: 13 }}>📖 Panduan Mode</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {[
                  { icon: '📨', title: 'Semua Email', desc: 'Kirim ke seluruh daftar perusahaan' },
                  { icon: '🔤', title: 'Pengelompokan → Abjad', desc: 'Contoh: pilih A-E = kirim ke semua email berawalan a, b, c, d, e' },
                  { icon: '🔢', title: 'Pengelompokan → Urutan', desc: 'Contoh: urutan 1-500 = 500 email pertama setelah diurutkan A-Z' },
                  { icon: '📦', title: 'Pengelompokan → Jumlah', desc: 'Contoh: mulai posisi 501, kirim 200 = batch ke-2' },
                  { icon: '🌐', title: 'Pengelompokan → Domain', desc: 'Kirim hanya ke gmail.com, yahoo.com, dll' },
                ].map(({ icon, title, desc }) => (
                  <div key={title} style={{ padding: '8px 10px', background: 'var(--bg-subtle)', borderRadius: 6 }}>
                    <div style={{ fontWeight: 600, color: 'var(--text-primary)', marginBottom: 2 }}>{icon} {title}</div>
                    <div style={{ fontSize: 11 }}>{desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
