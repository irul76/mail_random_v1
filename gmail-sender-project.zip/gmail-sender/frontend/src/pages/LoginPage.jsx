import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { Mail, Lock, Eye, EyeOff, ExternalLink } from 'lucide-react';

export default function LoginPage() {
  const { user, checkAuth } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [appPassword, setAppPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) navigate('/', { replace: true });
  }, [user, navigate]);

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!email || !appPassword) {
      toast.error('Email dan App Password wajib diisi');
      return;
    }
    setLoading(true);
    try {
      await api.post('/auth/login', { email, app_password: appPassword });
      await checkAuth();
      navigate('/', { replace: true });
    } catch (err) {
      toast.error(err.response?.data?.error || 'Login gagal');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--bg)',
      padding: 20,
    }}>
      <div style={{ width: '100%', maxWidth: 420 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{
            display: 'inline-flex',
            width: 60, height: 60,
            background: 'var(--accent)',
            borderRadius: 16,
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 14,
            boxShadow: '0 8px 24px rgba(232,93,38,0.3)',
          }}>
            <Mail size={28} color="#fff" />
          </div>
          <h1 style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-0.04em', marginBottom: 6 }}>
            Gmail Sender
          </h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>
            Login dengan Gmail + App Password
          </p>
        </div>

        {/* Form */}
        <div className="card" style={{ padding: 28 }}>
          <form onSubmit={handleLogin}>
            <div style={{ marginBottom: 14 }}>
              <label className="label">Alamat Gmail</label>
              <input
                className="input"
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="namakamu@gmail.com"
                autoComplete="email"
              />
            </div>

            <div style={{ marginBottom: 20 }}>
              <label className="label">App Password</label>
              <div style={{ position: 'relative' }}>
                <input
                  className="input"
                  type={showPass ? 'text' : 'password'}
                  value={appPassword}
                  onChange={e => setAppPassword(e.target.value)}
                  placeholder="xxxx xxxx xxxx xxxx"
                  style={{ paddingRight: 40, fontFamily: 'var(--font-mono)', letterSpacing: '0.1em' }}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(p => !p)}
                  style={{
                    position: 'absolute', right: 10, top: '50%',
                    transform: 'translateY(-50%)',
                    background: 'none', border: 'none', cursor: 'pointer',
                    color: 'var(--text-muted)', padding: 2,
                  }}
                >
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn btn-primary btn-lg"
              style={{ width: '100%', justifyContent: 'center' }}
            >
              {loading ? <span className="spinner" style={{ width: 16, height: 16 }} /> : <Lock size={16} />}
              {loading ? 'Memverifikasi...' : 'Masuk'}
            </button>
          </form>

          {/* Guide */}
          <div style={{
            marginTop: 20,
            padding: 14,
            background: 'var(--bg-subtle)',
            borderRadius: 'var(--radius-sm)',
            fontSize: 12,
            color: 'var(--text-secondary)',
            lineHeight: 1.7,
          }}>
            <div style={{ fontWeight: 700, marginBottom: 6, color: 'var(--text-primary)' }}>
              🔑 Cara dapat App Password:
            </div>
            <ol style={{ paddingLeft: 16 }}>
              <li>Buka <a href="https://myaccount.google.com/security" target="_blank" rel="noreferrer" style={{ color: 'var(--accent)' }}>myaccount.google.com/security</a></li>
              <li>Aktifkan <strong>2-Step Verification</strong></li>
              <li>Cari <strong>"App passwords"</strong></li>
              <li>Pilih <strong>Mail → Windows Computer</strong></li>
              <li>Copy password 16 karakter yang muncul</li>
            </ol>
            <a
              href="https://myaccount.google.com/apppasswords"
              target="_blank"
              rel="noreferrer"
              className="btn btn-secondary btn-sm"
              style={{ marginTop: 10, display: 'inline-flex', alignItems: 'center', gap: 5 }}
            >
              <ExternalLink size={12} /> Buka App Passwords
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
