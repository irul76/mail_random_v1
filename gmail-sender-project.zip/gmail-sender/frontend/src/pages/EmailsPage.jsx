import React, { useEffect, useState, useCallback } from 'react';
import { emailsAPI } from '../utils/api';
import toast from 'react-hot-toast';
import { Plus, Trash2, Edit2, Check, X, Upload, Clipboard, Search, AlertCircle } from 'lucide-react';

export default function EmailsPage() {
  const [emails, setEmails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [bulkText, setBulkText] = useState('');
  const [bulkLoading, setBulkLoading] = useState(false);
  const [showBulk, setShowBulk] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [newCompany, setNewCompany] = useState('');
  const [addLoading, setAddLoading] = useState(false);
  const [editId, setEditId] = useState(null);
  const [editData, setEditData] = useState({});
  const [search, setSearch] = useState('');
  const [confirmDeleteAll, setConfirmDeleteAll] = useState(false);

  const fetchEmails = useCallback(async () => {
    try {
      const { data } = await emailsAPI.getAll();
      setEmails(data.emails);
    } catch {
      toast.error('Gagal memuat daftar email');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchEmails(); }, [fetchEmails]);

  const handleBulkAdd = async () => {
    if (!bulkText.trim()) return;
    setBulkLoading(true);
    try {
      const { data } = await emailsAPI.addBulk(bulkText);
      toast.success(`✅ Ditambahkan: ${data.added} | Duplikat: ${data.duplicates} | Tidak valid: ${data.invalid}`);
      setBulkText('');
      setShowBulk(false);
      fetchEmails();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Gagal menambahkan email');
    } finally {
      setBulkLoading(false);
    }
  };

  const handleAddOne = async (e) => {
    e.preventDefault();
    if (!newEmail.trim()) return;
    setAddLoading(true);
    try {
      await emailsAPI.addOne(newEmail.trim(), newCompany.trim());
      toast.success('Email ditambahkan');
      setNewEmail('');
      setNewCompany('');
      fetchEmails();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Gagal menambahkan email');
    } finally {
      setAddLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await emailsAPI.delete(id);
      setEmails(prev => prev.filter(e => e.id !== id));
      toast.success('Email dihapus');
    } catch {
      toast.error('Gagal menghapus');
    }
  };

  const handleDeleteAll = async () => {
    try {
      await emailsAPI.deleteAll();
      setEmails([]);
      setConfirmDeleteAll(false);
      toast.success('Semua email dihapus');
    } catch {
      toast.error('Gagal menghapus semua');
    }
  };

  const startEdit = (email) => {
    setEditId(email.id);
    setEditData({ email: email.email, company_name: email.company_name || '' });
  };

  const saveEdit = async (id) => {
    try {
      const { data } = await emailsAPI.update(id, editData);
      setEmails(prev => prev.map(e => e.id === id ? data.email : e));
      setEditId(null);
      toast.success('Email diperbarui');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Gagal menyimpan');
    }
  };

  const filtered = emails.filter(e =>
    e.email.toLowerCase().includes(search.toLowerCase()) ||
    (e.company_name || '').toLowerCase().includes(search.toLowerCase())
  );

  const validCount = emails.filter(e => e.is_valid).length;

  return (
    <div>
      <div className="page-header">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <h1>Daftar Perusahaan</h1>
            <p>
              {emails.length} email · <span style={{ color: 'var(--success)' }}>{validCount} valid</span>
              {emails.length - validCount > 0 && (
                <span style={{ color: 'var(--danger)' }}> · {emails.length - validCount} tidak valid</span>
              )}
            </p>
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button onClick={() => setShowBulk(!showBulk)} className="btn btn-secondary btn-sm">
              <Upload size={13} /> Import Massal
            </button>
            {emails.length > 0 && !confirmDeleteAll && (
              <button onClick={() => setConfirmDeleteAll(true)} className="btn btn-ghost btn-sm" style={{ color: 'var(--danger)' }}>
                <Trash2 size={13} /> Hapus Semua
              </button>
            )}
            {confirmDeleteAll && (
              <>
                <button onClick={handleDeleteAll} className="btn btn-danger btn-sm">Konfirmasi Hapus</button>
                <button onClick={() => setConfirmDeleteAll(false)} className="btn btn-secondary btn-sm">Batal</button>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="page-body">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Bulk import */}
          {showBulk && (
            <div className="card fade-in">
              <div style={{ fontWeight: 600, marginBottom: 10, fontSize: 14 }}>
                <Clipboard size={14} style={{ marginRight: 6, verticalAlign: 'middle' }} />
                Import Email Massal
              </div>
              <p style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 10 }}>
                Paste email dipisahkan dengan baris baru, koma, atau titik koma. Duplikat otomatis diabaikan.
              </p>
              <textarea
                className="textarea"
                rows={8}
                value={bulkText}
                onChange={e => setBulkText(e.target.value)}
                placeholder="hr@perusahaan1.com&#10;rekrutmen@perusahaan2.com&#10;hrd@startup3.co.id"
                style={{ fontFamily: 'var(--font-mono)', fontSize: 13 }}
              />
              <div style={{ display: 'flex', gap: 8, marginTop: 10, justifyContent: 'flex-end' }}>
                <button onClick={() => setShowBulk(false)} className="btn btn-ghost btn-sm">Batal</button>
                <button onClick={handleBulkAdd} disabled={bulkLoading || !bulkText.trim()} className="btn btn-primary btn-sm">
                  {bulkLoading ? <span className="spinner" style={{ width: 14, height: 14 }} /> : <Upload size={13} />}
                  Import
                </button>
              </div>
            </div>
          )}

          {/* Add single email */}
          <div className="card">
            <div style={{ fontWeight: 600, marginBottom: 10, fontSize: 14 }}>
              <Plus size={14} style={{ marginRight: 6, verticalAlign: 'middle' }} />
              Tambah Email
            </div>
            <form onSubmit={handleAddOne} style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <input
                className="input"
                type="email"
                value={newEmail}
                onChange={e => setNewEmail(e.target.value)}
                placeholder="hr@perusahaan.com"
                style={{ flex: 2, minWidth: 200 }}
              />
              <input
                className="input"
                value={newCompany}
                onChange={e => setNewCompany(e.target.value)}
                placeholder="Nama Perusahaan (opsional)"
                style={{ flex: 2, minWidth: 160 }}
              />
              <button type="submit" disabled={addLoading || !newEmail} className="btn btn-primary">
                {addLoading ? <span className="spinner" style={{ width: 14, height: 14 }} /> : <Plus size={14} />}
                Tambah
              </button>
            </form>
          </div>

          {/* Search */}
          {emails.length > 0 && (
            <div style={{ position: 'relative' }}>
              <Search size={14} style={{
                position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)',
                color: 'var(--text-muted)'
              }} />
              <input
                className="input"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Cari email atau perusahaan..."
                style={{ paddingLeft: 32 }}
              />
            </div>
          )}

          {/* Email list */}
          {loading ? (
            <div style={{ display: 'flex', gap: 10, color: 'var(--text-muted)', alignItems: 'center' }}>
              <span className="spinner" /> Memuat...
            </div>
          ) : filtered.length === 0 ? (
            <div className="empty-state card">
              <AlertCircle size={32} />
              <p style={{ marginTop: 8, fontWeight: 600 }}>Belum ada email</p>
              <p>Tambahkan email perusahaan di atas atau import massal.</p>
            </div>
          ) : (
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ maxHeight: 480, overflowY: 'auto' }}>
                {filtered.map((email, i) => (
                  <div
                    key={email.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 10,
                      padding: '10px 16px',
                      borderBottom: i < filtered.length - 1 ? '1px solid var(--border)' : 'none',
                      background: editId === email.id ? 'var(--bg-subtle)' : 'transparent',
                      transition: 'background 0.1s',
                    }}
                  >
                    {/* Valid indicator */}
                    <div style={{
                      width: 8, height: 8, borderRadius: '50%', flexShrink: 0,
                      background: email.is_valid ? 'var(--success)' : 'var(--danger)',
                    }} />

                    {editId === email.id ? (
                      <>
                        <input
                          className="input"
                          value={editData.email}
                          onChange={e => setEditData(p => ({ ...p, email: e.target.value }))}
                          style={{ flex: 2, padding: '5px 9px', fontSize: 13 }}
                        />
                        <input
                          className="input"
                          value={editData.company_name}
                          onChange={e => setEditData(p => ({ ...p, company_name: e.target.value }))}
                          placeholder="Nama perusahaan"
                          style={{ flex: 1.5, padding: '5px 9px', fontSize: 13 }}
                        />
                        <button onClick={() => saveEdit(email.id)} className="btn btn-success btn-sm btn-icon">
                          <Check size={13} />
                        </button>
                        <button onClick={() => setEditId(null)} className="btn btn-ghost btn-sm btn-icon">
                          <X size={13} />
                        </button>
                      </>
                    ) : (
                      <>
                        <div style={{ flex: 2, minWidth: 0 }}>
                          <div style={{ fontSize: 13, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {email.email}
                          </div>
                          {email.company_name && (
                            <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{email.company_name}</div>
                          )}
                        </div>
                        <div style={{ display: 'flex', gap: 4, marginLeft: 'auto' }}>
                          <button onClick={() => startEdit(email)} className="btn btn-ghost btn-sm btn-icon">
                            <Edit2 size={13} />
                          </button>
                          <button onClick={() => handleDelete(email.id)} className="btn btn-ghost btn-sm btn-icon" style={{ color: 'var(--danger)' }}>
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
