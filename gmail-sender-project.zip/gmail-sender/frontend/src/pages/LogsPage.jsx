import React, { useEffect, useState } from 'react';
import { sendingAPI } from '../utils/api';
import toast from 'react-hot-toast';
import { CheckCircle, XCircle, Clock, RefreshCw, Ban, AlertTriangle } from 'lucide-react';

const statusIcon = {
  sent: <CheckCircle size={13} color="var(--success)" />,
  failed: <XCircle size={13} color="var(--danger)" />,
  blocked: <Ban size={13} color="var(--danger)" />,
  spam: <AlertTriangle size={13} color="var(--warning)" />,
  pending: <Clock size={13} color="var(--text-muted)" />,
};

const statusBadge = {
  sent: 'badge-success',
  failed: 'badge-danger',
  blocked: 'badge-danger',
  spam: 'badge-warning',
  pending: 'badge-neutral',
};

function timeAgo(ts) {
  if (!ts) return '—';
  const diff = Math.floor(Date.now() / 1000) - ts;
  if (diff < 60) return `${diff}d lalu`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m lalu`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}j lalu`;
  return `${Math.floor(diff / 86400)} hari lalu`;
}

export default function LogsPage() {
  const [logs, setLogs] = useState([]);
  const [total, setTotal] = useState(0);
  const [sessions, setSessions] = useState([]);
  const [selectedSession, setSelectedSession] = useState('');
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [page, setPage] = useState(1);
  const LIMIT = 50;

  const fetchLogs = async (p = 1) => {
    setLoading(true);
    try {
      const params = { page: p, limit: LIMIT };
      if (selectedSession) params.session_id = selectedSession;
      if (filter !== 'all') params.status = filter;
      const { data } = await sendingAPI.getLogs(params);
      setLogs(data.logs);
      setTotal(data.total);
    } catch { toast.error('Gagal memuat log'); }
    finally { setLoading(false); }
  };

  const fetchSessions = async () => {
    try {
      const { data } = await sendingAPI.getSessions();
      setSessions(data.sessions || []);
    } catch {}
  };

  useEffect(() => { fetchSessions(); }, []);
  useEffect(() => { setPage(1); fetchLogs(1); }, [filter, selectedSession]);

  const statusCounts = {
    sent: logs.filter(l => l.status === 'sent').length,
    failed: logs.filter(l => l.status === 'failed').length,
    blocked: logs.filter(l => l.status === 'blocked').length,
    spam: logs.filter(l => l.status === 'spam').length,
    pending: logs.filter(l => l.status === 'pending').length,
  };

  return (
    <div>
      <div className="page-header">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h1>Log Pengiriman</h1>
            <p>Riwayat semua email yang telah diproses</p>
          </div>
          <button onClick={() => fetchLogs(page)} className="btn btn-secondary btn-sm">
            <RefreshCw size={13} /> Refresh
          </button>
        </div>
      </div>

      <div className="page-body">
        {/* Session filter */}
        {sessions.length > 0 && (
          <div style={{ marginBottom: 14 }}>
            <label className="label">Filter Sesi</label>
            <select className="input select" value={selectedSession} onChange={e => setSelectedSession(e.target.value)} style={{ maxWidth: 400 }}>
              <option value="">Semua Sesi</option>
              {sessions.map(s => (
                <option key={s.id} value={s.id}>
                  {s.subject} — {new Date(s.created_at * 1000).toLocaleDateString('id-ID')} ({s.sent_count}/{s.total_emails} terkirim)
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Status filter tabs */}
        <div style={{ display: 'flex', gap: 6, marginBottom: 16, flexWrap: 'wrap' }}>
          {[
            { key: 'all', label: `Semua (${total})` },
            { key: 'sent', label: `✅ Terkirim (${statusCounts.sent})` },
            { key: 'failed', label: `❌ Gagal (${statusCounts.failed})` },
            { key: 'blocked', label: `🚫 Diblokir (${statusCounts.blocked})` },
            { key: 'spam', label: `⚠️ Spam (${statusCounts.spam})` },
            { key: 'pending', label: `⏳ Pending (${statusCounts.pending})` },
          ].map(({ key, label }) => (
            <button key={key} onClick={() => setFilter(key)} className={`btn btn-sm ${filter === key ? 'btn-primary' : 'btn-secondary'}`}>
              {label}
            </button>
          ))}
        </div>

        {loading ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, color: 'var(--text-muted)' }}>
            <span className="spinner" /> Memuat log...
          </div>
        ) : logs.length === 0 ? (
          <div className="card empty-state">
            <Clock size={32} />
            <p style={{ fontWeight: 600, marginTop: 8 }}>Tidak ada log</p>
            <p>Mulai kirim email untuk melihat riwayat di sini.</p>
          </div>
        ) : (
          <>
            <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead>
                  <tr style={{ background: 'var(--bg-subtle)', borderBottom: '1.5px solid var(--border)' }}>
                    {['Email Tujuan', 'Perusahaan', 'Posisi', 'Status', 'Waktu'].map(h => (
                      <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 600, fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {logs.map((log, i) => (
                    <tr key={log.id} style={{ borderBottom: i < logs.length - 1 ? '1px solid var(--border)' : 'none' }}
                      onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-subtle)'}
                      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                      <td style={{ padding: '10px 14px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontFamily: 'var(--font-mono)', fontSize: 12 }}>
                          {statusIcon[log.status] || statusIcon.pending}
                          {log.recipient_email}
                        </div>
                        {log.error_message && (
                          <div style={{ fontSize: 10, color: 'var(--danger)', marginTop: 2, maxWidth: 260, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {log.error_message}
                          </div>
                        )}
                      </td>
                      <td style={{ padding: '10px 14px', color: 'var(--text-secondary)', fontSize: 12 }}>
                        {log.company_name || '—'}
                      </td>
                      <td style={{ padding: '10px 14px', color: 'var(--text-secondary)', fontSize: 12 }}>
                        {log.subject}
                      </td>
                      <td style={{ padding: '10px 14px' }}>
                        <span className={`badge ${statusBadge[log.status] || 'badge-neutral'}`}>
                          {log.status}
                        </span>
                      </td>
                      <td style={{ padding: '10px 14px', color: 'var(--text-muted)', fontSize: 11 }}>
                        {timeAgo(log.sent_at || log.created_at)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {total > LIMIT && (
              <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 14 }}>
                <button className="btn btn-secondary btn-sm" disabled={page === 1} onClick={() => { setPage(p => p - 1); fetchLogs(page - 1); }}>Sebelumnya</button>
                <span style={{ padding: '5px 12px', fontSize: 12, color: 'var(--text-secondary)' }}>Halaman {page} dari {Math.ceil(total / LIMIT)}</span>
                <button className="btn btn-secondary btn-sm" disabled={page * LIMIT >= total} onClick={() => { setPage(p => p + 1); fetchLogs(page + 1); }}>Berikutnya</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
