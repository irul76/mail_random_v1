import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';

const api = axios.create({ baseURL: API_URL, withCredentials: true, timeout: 30000 });

api.interceptors.response.use(res => res, err => {
  if (err.response?.status === 401) window.dispatchEvent(new CustomEvent('auth:expired'));
  return Promise.reject(err);
});

export default api;

export const authAPI = {
  login: (email, app_password) => api.post('/auth/login', { email, app_password }),
  getMe: () => api.get('/auth/me'),
  logout: () => api.post('/auth/logout'),
};

export const profileAPI = {
  get: () => api.get('/api/profile'),
  update: (formData) => api.put('/api/profile', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
  downloadCV: () => `${API_URL}/api/profile/cv/download`,
};

export const emailsAPI = {
  getAll: () => api.get('/api/emails'),
  addBulk: (emailsText) => api.post('/api/emails/bulk', { emailsText }),
  addOne: (email, company_name) => api.post('/api/emails', { email, company_name }),
  update: (id, data) => api.put(`/api/emails/${id}`, data),
  delete: (id) => api.delete(`/api/emails/${id}`),
  deleteAll: () => api.delete('/api/emails'),
};

export const sendingAPI = {
  start: (subject, target_emails, delay_seconds, group_filter) =>
    api.post('/api/sending/start', { subject, target_emails, delay_seconds, group_filter }),
  pause: () => api.post('/api/sending/pause'),
  resume: () => api.post('/api/sending/resume'),
  stop: () => api.post('/api/sending/stop'),
  getStatus: () => api.get('/api/sending/status'),
  getSessions: () => api.get('/api/sending/sessions'),
  getLogs: (params) => api.get('/api/sending/logs', { params }),
  getStats: () => api.get('/api/sending/stats'),
  previewGroup: (group_filter) => api.post('/api/sending/preview-group', { group_filter }),
  getProgressURL: () => `${API_URL}/api/sending/progress`,
};
