# 📧 Gmail Sender — Job Application Email Automation

Kirim email lamaran kerja otomatis ke banyak perusahaan dengan Gmail App Password.

> ✅ Tidak perlu Google Cloud / OAuth — cukup Gmail App Password

---

## ⚡ Quick Start

### 1. Gmail App Password
1. Buka [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
2. Aktifkan 2-Step Verification jika belum
3. Buat App Password baru → copy 16 karakter

### 2. Jalankan Backend
```bash
cd backend
npm install
cp .env.example .env
# Edit .env: isi SESSION_SECRET
npm run dev
# → http://localhost:3001
```

### 3. Jalankan Frontend
```bash
cd frontend
npm install
npm start
# → http://localhost:3000
```

---

## 🚀 Fitur Lengkap

### Login
- Masukkan Gmail + App Password → langsung bisa pakai

### Profil Pelamar
- Isi data diri lengkap (nama, TTL, agama, usia, dll)
- Pengalaman kerja bisa ditambah berkali-kali
- Keahlian bisa ditambah berkali-kali
- **Preview email langsung terlihat dan bisa diedit bebas**
- Tombol Reset Otomatis untuk sinkron ulang dari form
- Upload CV (PDF/DOC, maks 10MB)

### Daftar Perusahaan
- Import massal 100+ email sekaligus (pisah enter/koma)
- Auto hapus duplikat
- CRUD per email (edit, hapus, tambah)

### Pengiriman Email
**Jeda Antar Email:**
- Bisa diatur dalam **detik** atau **menit**
- Minimum 1 detik
- Countdown realtime saat menunggu

**4 Mode Pengiriman:**
- **Semua Email** — kirim ke seluruh daftar
- **Pengelompokan** — filter canggih:
  - **Abjad** — pilih huruf awal (A, B, C, dll)
  - **Urutan** — dari urutan ke-N sampai ke-M (A-Z)
  - **Jumlah** — kirim N email mulai dari posisi tertentu (batch)
  - **Domain** — kirim ke domain tertentu (gmail.com, co.id, dll)
- **Pilih Manual** — centang email satu-satu dari daftar
- **Ketik Manual** — paste email langsung tanpa daftar

**Kontrol:**
- ▶️ Start / ⏸ Pause / ▶️ Resume / ⏹ Stop
- Progress bar realtime
- Countdown per email

### Statistik
- ✅ Terkirim
- ❌ Gagal
- 🚫 Diblokir (server tolak)
- ⚠️ Masuk Spam
- ⏱ Waktu berjalan + estimasi selesai

### Log Pengiriman
- Filter per sesi
- Filter per status (terkirim/gagal/diblokir/spam)
- Riwayat semua email yang diproses

---

## 📝 Variabel Email Otomatis

Dalam isi email, `[Nama Perusahaan]` dan `[POSISI]` diganti otomatis saat pengiriman.

---

## 🔧 Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Login gagal | Pastikan App Password 16 karakter, 2FA aktif |
| Email masuk spam | Naikkan jeda (min 30-60 detik) |
| Diblokir server | Email tujuan tidak valid / server reject |
| Backend restart terus | Pastikan `nodemon.json` ada di folder backend |
