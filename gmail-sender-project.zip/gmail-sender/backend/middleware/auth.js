const db = require('../config/database');

const requireAuth = async (req, res, next) => {
  const userId = req.session?.userId;
  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized', message: 'Please login first' });
  }

  const user = db.findUserById(userId);
  if (!user) {
    req.session.destroy();
    return res.status(401).json({ error: 'Unauthorized', message: 'User not found' });
  }

  req.user = user;
  next();
};

module.exports = { requireAuth };
