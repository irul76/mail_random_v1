const nodemailer = require('nodemailer');

function createTransporter(gmailUser, appPassword) {
  return nodemailer.createTransport({
    service: 'gmail',
    auth: { user: gmailUser, pass: appPassword.replace(/\s/g, '') },
  });
}

async function sendGmailEmail({ user, to, subject, bodyText, cvBuffer, cvFilename, cvMimeType }) {
  const transporter = createTransporter(user.email, user.app_password);
  const mailOptions = {
    from: `${user.name || user.email} <${user.email}>`,
    to, subject,
    text: bodyText,
  };
  if (cvBuffer && cvFilename) {
    mailOptions.attachments = [{ filename: cvFilename, content: cvBuffer, contentType: cvMimeType }];
  }
  return await transporter.sendMail(mailOptions);
}

// Build from structured fields (used when no custom template)
function buildEmailBody(profile, position, companyName) {
  const experiences = (profile.work_experiences || [])
    .filter(e => e && e.trim())
    .map((e, i) => `${i + 1}.${e}`)
    .join('\n');
  const skillsList = (profile.skills || [])
    .filter(s => s && s.trim())
    .map(s => `- ${s}`)
    .join('\n');

  return `Kepada Yth
Bapak/Ibu HRD ${companyName}

Dengan hormat,

Sehubungan dengan adanya informasi lowongan pekerjaan di perusahaan yang bapak atau ibu pimpin, maka dengan ini saya berniat melamar pekerjaan untuk posisi ${position}. Data diri saya sebagai berikut :

Nama : ${profile.full_name || ''}
Tempat, tanggal lahir : ${profile.birth_place || ''}, ${profile.birth_date || ''}
Agama : ${profile.religion || ''}
Usia : ${profile.age || ''} Tahun
Jenis Kelamin : ${profile.gender || ''}
Alamat : ${profile.address || ''}
Tinggi Badan : ${profile.height || ''} Cm
Berat Badan : ${profile.weight || ''} Kg
Pendidikan Terakhir : ${profile.education || ''}
Lulusan Tahun : ${profile.graduation_year || ''}
Vaksin : ${profile.vaccine || ''}
Pengalaman Kerja :
${experiences}
No HP/WA : ${profile.phone || ''}
Email : ${profile.email_contact || ''}
Keahlian :
${skillsList}

Atas perhatian bapak atau ibu saya ucapkan terimakasih.

Hormat saya
( ${profile.full_name || ''} )`;
}

// Final body: use saved custom template if exists, else build from fields
// Replace [Nama Perusahaan] and [POSISI] placeholders
function resolveEmailBody(profile, position, companyName) {
  let body = profile.email_template
    ? profile.email_template
    : buildEmailBody(profile, position, companyName);

  // Replace placeholders
  body = body.replace(/\[Nama Perusahaan\]/gi, companyName);
  body = body.replace(/\[POSISI\]/gi, position);
  return body;
}

module.exports = { sendGmailEmail, buildEmailBody, resolveEmailBody };
