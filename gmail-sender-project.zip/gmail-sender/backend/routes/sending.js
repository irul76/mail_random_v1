const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const db = require('../config/database');
const { sendGmailEmail, resolveEmailBody } = require('../utils/gmail');

const activeSessions = new Map();
const sseClients = new Map();

function broadcastProgress(userId, data) {
  const clients = sseClients.get(userId) || [];
  const msg = `data: ${JSON.stringify(data)}\n\n`;
  clients.forEach(res => { try { res.write(msg); } catch (e) {} });
}

// ─── Helper: filter & group email targets ─────────────────────────────────────
function applyGroupFilter(emails, groupFilter) {
  if (!groupFilter || groupFilter.type === 'all') return emails;

  switch (groupFilter.type) {
    case 'abjad': {
      // e.g. { type: 'abjad', letters: ['a','b','c'] }
      const letters = (groupFilter.letters || []).map(l => l.toLowerCase());
      return emails.filter(e => letters.includes((e.email.split('@')[0][0] || '').toLowerCase()));
    }
    case 'range': {
      // e.g. { type: 'range', from: 0, to: 499 } (index-based)
      const from = parseInt(groupFilter.from) || 0;
      const to = parseInt(groupFilter.to) ?? emails.length - 1;
      return emails.slice(from, to + 1);
    }
    case 'domain': {
      // e.g. { type: 'domain', domains: ['gmail.com','yahoo.com'] }
      const domains = (groupFilter.domains || []).map(d => d.toLowerCase());
      const emailDomain = e => e.email.split('@')[1]?.toLowerCase() || ''; return emails.filter(e => domains.some(d => emailDomain(e) === d || emailDomain(e).endsWith('.' + d)));
    }
    case 'count': {
      // e.g. { type: 'count', limit: 100, offset: 0 }
      const offset = parseInt(groupFilter.offset) || 0;
      const limit = parseInt(groupFilter.limit) || emails.length;
      return emails.slice(offset, offset + limit);
    }
    default:
      return emails;
  }
}

// ─── SSE realtime progress ────────────────────────────────────────────────────
router.get('/progress', requireAuth, (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();
  const userId = req.user.id;
  if (!sseClients.has(userId)) sseClients.set(userId, []);
  sseClients.get(userId).push(res);
  const session = db.getLastSession(userId);
  if (session) res.write(`data: ${JSON.stringify({ type: 'session', session })}\n\n`);
  req.on('close', () => {
    sseClients.set(userId, (sseClients.get(userId) || []).filter(c => c !== res));
  });
});

// ─── Start sending ────────────────────────────────────────────────────────────
router.post('/start', requireAuth, async (req, res) => {
  const {
    subject,
    target_emails,   // array of email strings (manual/selected mode)
    delay_seconds = 60, // delay in SECONDS (default 60s = 1 menit)
    group_filter,    // object: { type, ...options }
  } = req.body;

  if (!subject) return res.status(400).json({ error: 'Posisi/subject wajib diisi' });

  const userId = req.user.id;
  if (activeSessions.has(userId)) return res.status(409).json({ error: 'Sesi pengiriman sudah aktif' });

  const profile = db.findProfileByUserId(userId);
  if (!profile || !profile.full_name) return res.status(400).json({ error: 'Lengkapi profil pelamar dulu' });

  // ── Resolve email list ──
  let emailTargets = [];

  if (target_emails && Array.isArray(target_emails) && target_emails.length > 0) {
    emailTargets = target_emails
      .map(e => ({ email: e.trim().toLowerCase(), company_name: e.split('@')[1]?.split('.')[0] || '' }))
      .filter(e => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.email));
  } else {
    // Load all valid emails from DB, sort A-Z by email
    const all = db.getEmailsByUserId(userId)
      .filter(e => e.is_valid === 1)
      .sort((a, b) => a.email.localeCompare(b.email))
      .map(e => ({ email: e.email, company_name: e.company_name || e.email.split('@')[1]?.split('.')[0] || '' }));

    // Apply group filter
    emailTargets = applyGroupFilter(all, group_filter);
  }

  if (emailTargets.length === 0) return res.status(400).json({ error: 'Tidak ada email valid untuk dikirim' });

  // ── Validate delay ──
  const delayMs = Math.max(1, parseInt(delay_seconds)) * 1000; // minimum 1 detik

  const session = db.createSession({
    user_id: userId,
    subject,
    total_emails: emailTargets.length,
    delay_seconds: parseInt(delay_seconds),
    group_filter: group_filter ? JSON.stringify(group_filter) : null,
  });

  db.createLogs(emailTargets.map(e => ({
    user_id: userId,
    session_id: session.id,
    recipient_email: e.email,
    company_name: e.company_name,
    subject,
  })));

  res.json({ sessionId: session.id, totalEmails: emailTargets.length, message: 'Pengiriman dimulai' });
  processEmailQueue(userId, session.id, subject, profile, req.user, delayMs);
});

router.post('/pause', requireAuth, (req, res) => {
  const ctrl = activeSessions.get(req.user.id);
  if (!ctrl) return res.status(404).json({ error: 'Tidak ada sesi aktif' });
  ctrl.paused = true;
  const s = db.getActiveSession(req.user.id);
  if (s) db.updateSession(s.id, { status: 'paused', paused_at: Math.floor(Date.now() / 1000) });
  broadcastProgress(req.user.id, { type: 'paused' });
  res.json({ success: true });
});

router.post('/resume', requireAuth, (req, res) => {
  const ctrl = activeSessions.get(req.user.id);
  if (!ctrl) return res.status(404).json({ error: 'Tidak ada sesi aktif' });
  ctrl.paused = false;
  const s = db.getActiveSession(req.user.id);
  if (s) db.updateSession(s.id, { status: 'running', paused_at: null });
  broadcastProgress(req.user.id, { type: 'resumed' });
  res.json({ success: true });
});

router.post('/stop', requireAuth, (req, res) => {
  const ctrl = activeSessions.get(req.user.id);
  if (!ctrl) return res.status(404).json({ error: 'Tidak ada sesi aktif' });
  ctrl.stopped = true;
  activeSessions.delete(req.user.id);
  const s = db.getActiveSession(req.user.id);
  if (s) db.updateSession(s.id, { status: 'stopped', completed_at: Math.floor(Date.now() / 1000) });
  broadcastProgress(req.user.id, { type: 'stopped' });
  res.json({ success: true });
});

router.get('/status', requireAuth, (req, res) => {
  res.json({ session: db.getLastSession(req.user.id) || null, isActive: activeSessions.has(req.user.id) });
});

router.get('/sessions', requireAuth, (req, res) => {
  res.json({ sessions: db.getAllSessions(req.user.id) });
});

router.get('/logs', requireAuth, (req, res) => {
  const { page = 1, limit = 50, status, session_id } = req.query;
  if (session_id) {
    const logs = db.getLogsBySession(session_id);
    return res.json({ logs, total: logs.length });
  }
  res.json(db.getLogsByUser(req.user.id, parseInt(page), parseInt(limit), status || null));
});

router.get('/stats', requireAuth, (req, res) => {
  res.json({ ...db.getStats(req.user.id), isActive: activeSessions.has(req.user.id) });
});

// ─── Email group preview (what emails will be sent given a filter) ────────────
router.post('/preview-group', requireAuth, (req, res) => {
  const { group_filter } = req.body;
  const all = db.getEmailsByUserId(req.user.id)
    .filter(e => e.is_valid === 1)
    .sort((a, b) => a.email.localeCompare(b.email));

  const filtered = applyGroupFilter(all, group_filter);
  res.json({
    total: filtered.length,
    preview: filtered.slice(0, 10).map(e => e.email), // show first 10
    totalAll: all.length,
  });
});

// ─── Async queue processor ────────────────────────────────────────────────────
async function processEmailQueue(userId, sessionId, subject, profile, user, delayMs) {
  const ctrl = { paused: false, stopped: false };
  activeSessions.set(userId, ctrl);

  const pendingLogs = db.getPendingLogs(sessionId);
  let sentCount = 0, failedCount = 0;
  const startedAt = Date.now();

  for (let i = 0; i < pendingLogs.length; i++) {
    const log = pendingLogs[i];
    if (ctrl.stopped) break;
    while (ctrl.paused && !ctrl.stopped) await sleep(500);
    if (ctrl.stopped) break;

    // Delay between emails (skip for first)
    if (i > 0) {
      let elapsed = 0;
      while (elapsed < delayMs) {
        if (ctrl.stopped || ctrl.paused) break;
        await sleep(500);
        elapsed += 500;

        // Broadcast countdown every second
        if (elapsed % 1000 === 0) {
          const remaining = delayMs - elapsed;
          broadcastProgress(userId, {
            type: 'countdown',
            nextIn: Math.ceil(remaining / 1000),
            nextInMs: remaining,
            sent: sentCount,
            failed: failedCount,
            remaining: pendingLogs.length - i,
          });
        }
      }
      if (ctrl.stopped) break;
      while (ctrl.paused && !ctrl.stopped) await sleep(500);
      if (ctrl.stopped) break;
    }

    const companyName = log.company_name || log.recipient_email.split('@')[1]?.split('.')[0] || 'Perusahaan';
    const bodyText = resolveEmailBody(profile, subject, companyName);
    const freshUser = db.findUserById(userId);

    let logStatus = 'failed';
    let errorMsg = null;

    try {
      const cvBuffer = profile.cv_data ? Buffer.from(profile.cv_data, 'base64') : null;
      await sendGmailEmail({
        user: freshUser,
        to: log.recipient_email,
        subject: `Lamaran Pekerjaan - ${subject}`,
        bodyText,
        cvBuffer,
        cvFilename: profile.cv_original_name,
        cvMimeType: profile.cv_mime_type,
      });
      logStatus = 'sent';
      sentCount++;
    } catch (error) {
      errorMsg = error.message;
      const msg = error.message.toLowerCase();
      if (msg.includes('550') || msg.includes('blocked') || msg.includes('rejected') || msg.includes('relay')) {
        logStatus = 'blocked';
        const cur = db.getLastSession(userId);
        db.updateSession(sessionId, { blocked_count: (cur?.blocked_count || 0) + 1 });
      } else if (msg.includes('spam') || msg.includes('554') || msg.includes('policy')) {
        logStatus = 'spam';
        const cur = db.getLastSession(userId);
        db.updateSession(sessionId, { spam_count: (cur?.spam_count || 0) + 1 });
      }
      failedCount++;
      console.error(`Failed → ${log.recipient_email}: ${error.message}`);
    }

    db.updateLog(log.id, { status: logStatus, error_message: errorMsg, sent_at: Math.floor(Date.now() / 1000) });
    db.updateSession(sessionId, { sent_count: sentCount, failed_count: failedCount });

    const elapsedSec = Math.floor((Date.now() - startedAt) / 1000);
    broadcastProgress(userId, {
      type: 'progress',
      sent: sentCount,
      failed: failedCount,
      total: pendingLogs.length,
      remaining: pendingLogs.length - i - 1,
      lastEmail: log.recipient_email,
      lastStatus: logStatus,
      elapsedSeconds: elapsedSec,
    });
  }

  if (!ctrl.stopped) {
    const done = sentCount + failedCount >= pendingLogs.length;
    db.updateSession(sessionId, { status: done ? 'completed' : 'stopped', completed_at: Math.floor(Date.now() / 1000) });
    broadcastProgress(userId, { type: 'completed', sent: sentCount, failed: failedCount, total: pendingLogs.length });
  }
  activeSessions.delete(userId);
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
module.exports = router;
