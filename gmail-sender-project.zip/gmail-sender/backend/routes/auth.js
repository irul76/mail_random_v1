const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const nodemailer = require('nodemailer');

// Login dengan email + app password (tidak perlu OAuth)
router.post('/login', async (req, res) => {
  const { email, app_password } = req.body;
  if (!email || !app_password) {
    return res.status(400).json({ error: 'Email dan App Password wajib diisi' });
  }

  // Verifikasi app password dengan coba kirim test (verify SMTP)
  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: email,
        pass: app_password.replace(/\s/g, ''),
      },
    });
    await transporter.verify();
  } catch (err) {
    return res.status(401).json({ error: 'Email atau App Password salah. Pastikan App Password sudah dibuat di Google Account.' });
  }

  // Simpan / update user
  const existing = db.findUserByEmail(email);
  const userId = existing?.id || uuidv4();
  const name = email.split('@')[0];

  db.upsertUser({
    id: userId,
    email,
    name: existing?.name || name,
    picture: existing?.picture || '',
    access_token: '',
    refresh_token: '',
    token_expiry: 0,
    app_password: app_password.replace(/\s/g, ''),
  });

  // Buat default profile kalau belum ada
  const existingProfile = db.findProfileByUserId(userId);
  if (!existingProfile) {
    const DEFAULT_TEMPLATE = `Yth. HRD/Rekrutmen {company},\n\nDengan hormat,\n\nSaya {name}, ingin melamar posisi {position} di perusahaan Anda.\n\n{description}\n\nBersama email ini, saya lampirkan CV saya untuk pertimbangan Bapak/Ibu.\n\nAtas perhatian dan kesempatan yang diberikan, saya ucapkan terima kasih.\n\nHormat saya,\n{name}\n{phone}`;
    db.upsertProfile(userId, { name: existing?.name || name, email_template: DEFAULT_TEMPLATE });
  }

  req.session.userId = userId;
  const user = db.findUserById(userId);
  const { app_password: _, ...safeUser } = user;
  res.json({ user: safeUser });
});

// Get current user
router.get('/me', (req, res) => {
  const userId = req.session?.userId;
  if (!userId) return res.json({ user: null });
  const user = db.findUserById(userId);
  if (!user) return res.json({ user: null });
  const { id, email, name, picture } = user;
  res.json({ user: { id, email, name, picture } });
});

// Logout
router.post('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.status(500).json({ error: 'Logout failed' });
    res.clearCookie('connect.sid');
    res.json({ success: true });
  });
});

module.exports = router;
