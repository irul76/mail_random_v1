const express = require('express');
const router = express.Router();
const multer = require('multer');
const { requireAuth } = require('../middleware/auth');
const db = require('../config/database');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    cb(allowed.includes(file.mimetype) ? null : new Error('Only PDF/DOC/DOCX'), allowed.includes(file.mimetype));
  }
});

router.get('/', requireAuth, (req, res) => {
  const profile = db.findProfileByUserId(req.user.id);
  if (!profile) return res.json({ profile: null });
  const { cv_data, ...safe } = profile;
  res.json({ profile: safe });
});

router.put('/', requireAuth, upload.single('cv'), (req, res) => {
  const {
    full_name, birth_place, birth_date, religion, age, gender, address,
    height, weight, education, graduation_year, vaccine,
    work_experiences, // JSON string array
    phone, email_contact, skills, // JSON string array
    email_template,
  } = req.body;

  const data = {
    full_name, birth_place, birth_date, religion, age, gender, address,
    height, weight, education, graduation_year, vaccine,
    work_experiences: work_experiences ? JSON.parse(work_experiences) : [],
    phone, email_contact,
    skills: skills ? JSON.parse(skills) : [],
    email_template,
  };

  if (req.file) {
    data.cv_filename = req.file.originalname;
    data.cv_original_name = req.file.originalname;
    data.cv_mime_type = req.file.mimetype;
    data.cv_data = req.file.buffer.toString('base64');
  }

  const updated = db.upsertProfile(req.user.id, data);
  const { cv_data, ...safe } = updated;
  res.json({ profile: safe, message: 'Profil tersimpan' });
});

router.get('/cv/download', requireAuth, (req, res) => {
  const profile = db.findProfileByUserId(req.user.id);
  if (!profile?.cv_data) return res.status(404).json({ error: 'CV tidak ditemukan' });
  res.setHeader('Content-Type', profile.cv_mime_type);
  res.setHeader('Content-Disposition', `attachment; filename="${profile.cv_original_name}"`);
  res.send(Buffer.from(profile.cv_data, 'base64'));
});

module.exports = router;
