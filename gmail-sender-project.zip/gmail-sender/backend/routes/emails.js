const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const db = require('../config/database');

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const validateEmail = (email) => EMAIL_REGEX.test(String(email).trim().toLowerCase());

const parseBulkEmails = (text) =>
  text.split(/[\n,;]+/).map(e => e.trim().toLowerCase()).filter(e => e.length > 0);

// Get all emails
router.get('/', requireAuth, (req, res) => {
  const emails = db.getEmailsByUserId(req.user.id);
  res.json({ emails });
});

// Add bulk emails
router.post('/bulk', requireAuth, (req, res) => {
  const { emailsText } = req.body;
  if (!emailsText) return res.status(400).json({ error: 'No emails provided' });

  const parsed = parseBulkEmails(emailsText);
  const results = { added: 0, duplicates: 0, invalid: 0, errors: [] };

  for (const email of parsed) {
    if (!validateEmail(email)) {
      results.invalid++;
      results.errors.push(`Invalid: ${email}`);
      continue;
    }
    const existing = db.findEmailByUserAndAddress(req.user.id, email);
    if (existing) { results.duplicates++; continue; }
    db.addEmail(req.user.id, email);
    results.added++;
  }

  res.json({ ...results, total: db.countEmailsByUser(req.user.id), message: `Added ${results.added} emails` });
});

// Add single email
router.post('/', requireAuth, (req, res) => {
  const { email, company_name } = req.body;
  if (!email) return res.status(400).json({ error: 'Email is required' });

  const normalized = email.trim().toLowerCase();
  if (!validateEmail(normalized)) return res.status(400).json({ error: 'Invalid email format' });

  const existing = db.findEmailByUserAndAddress(req.user.id, normalized);
  if (existing) return res.status(409).json({ error: 'Email already exists' });

  const entry = db.addEmail(req.user.id, normalized, company_name || null);
  res.status(201).json({ email: entry });
});

// Update email
router.put('/:id', requireAuth, (req, res) => {
  const { email, company_name } = req.body;
  const { id } = req.params;

  const existing = db.getEmailsByUserId(req.user.id).find(e => e.id === id);
  if (!existing) return res.status(404).json({ error: 'Email not found' });

  const normalized = email?.trim().toLowerCase() || existing.email;
  const is_valid = validateEmail(normalized) ? 1 : 0;

  const updated = db.updateEmail(id, req.user.id, { email: normalized, company_name: company_name ?? existing.company_name, is_valid });
  res.json({ email: updated });
});

// Delete single email
router.delete('/:id', requireAuth, (req, res) => {
  const changes = db.deleteEmail(req.params.id, req.user.id);
  if (changes === 0) return res.status(404).json({ error: 'Email not found' });
  res.json({ success: true });
});

// Delete all emails
router.delete('/', requireAuth, (req, res) => {
  const deleted = db.deleteAllEmailsByUser(req.user.id);
  res.json({ success: true, deleted });
});

module.exports = router;
