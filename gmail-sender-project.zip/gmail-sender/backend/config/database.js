const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const DB_PATH = process.env.DB_PATH || './database.json';
const adapter = new FileSync(path.resolve(DB_PATH));
const db = low(adapter);

db.defaults({
  users: [],
  applicant_profiles: [],
  company_emails: [],
  email_logs: [],
  sending_sessions: [],
}).write();

const dbHelpers = {
  // USERS
  findUserByEmail: (email) => db.get('users').find({ email }).value(),
  findUserById: (id) => db.get('users').find({ id }).value(),

  upsertUser: ({ id, email, name, picture, access_token, refresh_token, token_expiry, app_password }) => {
    const existing = db.get('users').find({ email }).value();
    const now = Math.floor(Date.now() / 1000);
    if (existing) {
      db.get('users').find({ email }).assign({
        name, picture, access_token,
        refresh_token: refresh_token || existing.refresh_token,
        token_expiry, updated_at: now,
        app_password: app_password || existing.app_password,
      }).write();
      return db.get('users').find({ email }).value();
    } else {
      const user = { id: id || uuidv4(), email, name, picture, access_token, refresh_token, token_expiry, app_password, created_at: now, updated_at: now };
      db.get('users').push(user).write();
      return user;
    }
  },

  // PROFILES — now supports rich fields
  findProfileByUserId: (user_id) => db.get('applicant_profiles').find({ user_id }).value(),

  upsertProfile: (user_id, data) => {
    const existing = db.get('applicant_profiles').find({ user_id }).value();
    const now = Math.floor(Date.now() / 1000);
    if (existing) {
      db.get('applicant_profiles').find({ user_id }).assign({ ...data, updated_at: now }).write();
    } else {
      db.get('applicant_profiles').push({ id: uuidv4(), user_id, ...data, created_at: now, updated_at: now }).write();
    }
    return db.get('applicant_profiles').find({ user_id }).value();
  },

  // COMPANY EMAILS
  getEmailsByUserId: (user_id) => db.get('company_emails').filter({ user_id }).sortBy('created_at').reverse().value(),
  findEmailByUserAndAddress: (user_id, email) => db.get('company_emails').find({ user_id, email }).value(),

  addEmail: (user_id, email, company_name = null) => {
    const entry = { id: uuidv4(), user_id, email, company_name, is_valid: 1, selected: true, created_at: Math.floor(Date.now() / 1000) };
    db.get('company_emails').push(entry).write();
    return entry;
  },

  updateEmail: (id, user_id, data) => {
    db.get('company_emails').find({ id, user_id }).assign(data).write();
    return db.get('company_emails').find({ id }).value();
  },

  deleteEmail: (id, user_id) => {
    const before = db.get('company_emails').size().value();
    db.get('company_emails').remove({ id, user_id }).write();
    return before - db.get('company_emails').size().value();
  },

  deleteAllEmailsByUser: (user_id) => {
    const count = db.get('company_emails').filter({ user_id }).size().value();
    db.get('company_emails').remove({ user_id }).write();
    return count;
  },

  countEmailsByUser: (user_id) => db.get('company_emails').filter({ user_id }).size().value(),

  // SENDING SESSIONS
  createSession: (data) => {
    const session = { id: uuidv4(), ...data, status: 'running', sent_count: 0, failed_count: 0, opened_count: 0, spam_count: 0, blocked_count: 0, started_at: Math.floor(Date.now() / 1000), created_at: Math.floor(Date.now() / 1000) };
    db.get('sending_sessions').push(session).write();
    return session;
  },

  updateSession: (id, data) => {
    db.get('sending_sessions').find({ id }).assign(data).write();
    return db.get('sending_sessions').find({ id }).value();
  },

  getLastSession: (user_id) => db.get('sending_sessions').filter({ user_id }).sortBy('created_at').reverse().first().value(),
  getActiveSession: (user_id) => db.get('sending_sessions').find(s => s.user_id === user_id && ['running', 'paused'].includes(s.status)).value(),
  getAllSessions: (user_id) => db.get('sending_sessions').filter({ user_id }).sortBy('created_at').reverse().value(),

  // EMAIL LOGS
  createLogs: (entries) => {
    const now = Math.floor(Date.now() / 1000);
    const logs = entries.map(e => ({ id: uuidv4(), ...e, status: 'pending', opened: false, is_spam: false, is_blocked: false, created_at: now }));
    logs.forEach(l => db.get('email_logs').push(l).write());
    return logs;
  },

  getPendingLogs: (session_id) => db.get('email_logs').filter({ session_id, status: 'pending' }).sortBy('created_at').value(),

  updateLog: (id, data) => {
    db.get('email_logs').find({ id }).assign(data).write();
  },

  getLogsByUser: (user_id, page = 1, limit = 50, statusFilter = null) => {
    let all = db.get('email_logs').filter({ user_id }).sortBy('created_at').reverse().value();
    if (statusFilter) all = all.filter(l => l.status === statusFilter);
    return { logs: all.slice((page - 1) * limit, page * limit), total: all.length };
  },

  getLogsBySession: (session_id) => db.get('email_logs').filter({ session_id }).sortBy('created_at').value(),

  // STATS
  getStats: (user_id) => ({
    totalCompanies: db.get('company_emails').filter({ user_id }).size().value(),
    totalSent: db.get('email_logs').filter({ user_id, status: 'sent' }).size().value(),
    totalFailed: db.get('email_logs').filter({ user_id, status: 'failed' }).size().value(),
    totalOpened: db.get('email_logs').filter({ user_id, opened: true }).size().value(),
    totalSpam: db.get('email_logs').filter({ user_id, is_spam: true }).size().value(),
    totalBlocked: db.get('email_logs').filter({ user_id, is_blocked: true }).size().value(),
    lastSession: db.get('sending_sessions').filter({ user_id }).sortBy('created_at').reverse().first().value() || null,
  }),
};

console.log('✅ Database (JSON) initialized successfully');
module.exports = dbHelpers;
